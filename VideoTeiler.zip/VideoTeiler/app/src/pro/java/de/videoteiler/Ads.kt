package de.videoteiler

import android.app.Activity
import android.widget.LinearLayout

/** Pro-Ausgabe: keine Werbung, kein Internet. */
object Ads {
    const val enabled = false

    @Suppress("UNUSED_PARAMETER")
    fun attach(activity: Activity, container: LinearLayout) {
    }

    @Suppress("UNUSED_PARAMETER")
    fun showIntroAd(activity: Activity) {
    }

    @Suppress("UNUSED_PARAMETER")
    fun showPrivacyOptions(activity: Activity) {
    }
}
