package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Verkleinert ein Video (kleinere Bildgröße und Datenrate) und speichert es unter Filme/Video-Teiler. */
class CompressActivity : Activity() {

    private val REQ = 91
    private val main = Handler(Looper.getMainLooper())
    private var src: Uri? = null
    private var info: SourceInfo? = null
    private var sizeBytes = 0L
    private var dispW = 0
    private var dispH = 0
    private var busy = false
    private var level = 1

    /** Name, kurze Seite in Pixel, Videodatenrate in Bit/s */
    private class Level(val label: String, val shortSide: Int, val bitrate: Int)

    private val levels = listOf(
        Level("Klein (480p)", 480, 1_200_000),
        Level("Mittel (720p)", 720, 2_500_000),
        Level("Hoch (1080p)", 1080, 5_000_000)
    )

    private lateinit var infoText: TextView
    private lateinit var estText: TextView
    private lateinit var pickBtn: Button
    private lateinit var goBtn: Button
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var resultBox: LinearLayout
    private val chips = ArrayList<Button>()

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        top.addView(
            Ui.header(this, "Video verkleinern", "Weniger Speicher, schneller zu senden.", Ui.TILE_ORANGE),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        )
        pickBtn = Ui.button(this, "Video auswählen", true) { Ui.pickVideo(this, REQ) }
        top.addView(pickBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        infoText = Ui.text(this, "Noch kein Video gewählt.", 15f, Ui.INK, false)
        Ui.panel(this, infoText)
        top.addView(infoText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })

        top.addView(Ui.text(this, "Qualität", 13f, Ui.MUTED, true), LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(14) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, l) in levels.withIndex()) {
            val b = Button(this).apply {
                text = l.label
                textSize = 13f
                setOnClickListener {
                    level = i
                    styleChips()
                    estimate()
                }
            }
            chips.add(b)
            row.addView(b, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(6) })
        }
        top.addView(row, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        styleChips()

        estText = Ui.text(this, "", 13f, Ui.MUTED, false)
        top.addView(estText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        goBtn = Ui.button(this, "Video verkleinern", true) { start() }
        goBtn.isEnabled = false
        top.addView(goBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(10) })

        progressText = Ui.text(this, "", 13f, Ui.MUTED, false)
        top.addView(progressText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            visibility = View.GONE
        }
        top.addView(progressBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(resultBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        val scroll = android.widget.ScrollView(this)
        scroll.addView(top, android.view.ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
    }

    private fun styleChips() {
        for ((i, b) in chips.withIndex()) {
            Ui.style3d(this, b, i == level, 12)
            b.textSize = 13f
            b.setPadding(dp(8), dp(12), dp(10), dp(18))
        }
    }

    private fun mb(bytes: Long) = "%.0f MB".format(bytes / 1_000_000.0)

    private fun estimate() {
        val inf = info ?: run { estText.text = ""; return }
        val l = levels[level]
        val secs = inf.durationUs / 1_000_000.0
        val est = ((l.bitrate + 128_000) * secs / 8).toLong()
        val smaller = sizeBytes > 0 && est < sizeBytes
        estText.text = if (smaller) "Ungefähr ${mb(est)} statt ${mb(sizeBytes)}."
        else "Das Video ist schon klein. Das Ergebnis wird kaum kleiner."
    }

    /** Bildhöhe, auf die verkleinert wird (0 = nicht verkleinern). Bezieht sich auf die kurze Seite. */
    private fun targetHeight(): Int {
        val l = levels[level]
        val shortSide = minOf(dispW, dispH)
        if (shortSide <= 0 || shortSide <= l.shortSide) return 0
        val f = l.shortSide.toDouble() / shortSide
        var h = Math.round(dispH * f).toInt()
        if (h % 2 != 0) h += 1
        return h
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val inf = Splitter.readInfo(this, uri)
                src = uri
                info = inf
                sizeBytes = querySize(uri)
                readDims(uri)
                infoText.text = "${inf.name}\nLänge ${Ui.fmt(inf.durationUs / 1_000_000L)} Min." +
                    (if (sizeBytes > 0) " · ${mb(sizeBytes)}" else "") +
                    (if (dispW > 0) " · ${dispW}×${dispH}" else "")
                goBtn.isEnabled = !busy
                estimate()
            } catch (e: Exception) {
                src = null
                info = null
                goBtn.isEnabled = false
                infoText.text = "Dieses Video konnte nicht gelesen werden."
                estText.text = ""
            }
            resultBox.removeAllViews()
            progressText.text = ""
        }
    }

    private fun querySize(uri: Uri): Long {
        try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
            }
        } catch (e: Exception) {
            // unbekannt
        }
        return 0L
    }

    private fun readDims(uri: Uri) {
        dispW = 0
        dispH = 0
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { dispW = h; dispH = w } else { dispW = w; dispH = h }
        } catch (e: Exception) {
            // Maße unbekannt: es wird nur die Datenrate gesenkt
        } finally {
            r.release()
        }
    }

    private fun start() {
        val uri = src ?: return
        val inf = info ?: return
        if (busy) return
        busy = true
        pickBtn.isEnabled = false
        goBtn.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        resultBox.removeAllViews()
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = false
        progressBar.max = 100
        progressBar.progress = 0
        progressText.text = "Verkleinere das Video (dauert je nach Länge) …"

        val base = inf.name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
            .trim('_')
            .take(40)
            .ifEmpty { "Video" }
        val tmp = File(cacheDir, "klein.tmp.mp4")
        val app = applicationContext
        val name = "${base}_klein.mp4"
        val l = levels[level]

        Transcoder.run(this, uri, tmp, 0L, 0L,
            onProgress = { pct -> progressBar.progress = pct },
            onDone = { err ->
                if (err != null) {
                    tmp.delete()
                    done(null, "Fehler: $err")
                } else {
                    Thread {
                        var out: Uri? = null
                        var msg: String? = null
                        var size = 0L
                        try {
                            out = Splitter.createOutput(app, name)
                            Splitter.copyToGallery(app, tmp, out)
                            size = tmp.length()
                            Splitter.finish(app, out)
                        } catch (e: Exception) {
                            msg = "Fehler: ${e.message ?: e.javaClass.simpleName}"
                            out?.let { Splitter.discard(app, it) }
                            out = null
                        }
                        tmp.delete()
                        val o = out
                        val m = msg
                        val sz = size
                        main.post { done(o, m ?: "Fertig: $name (${mb(sz)}) in Filme/Video-Teiler gespeichert.") }
                    }.start()
                }
            },
            targetHeight = targetHeight(),
            videoBitrate = l.bitrate
        )
    }

    private fun done(uri: Uri?, message: String) {
        busy = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        pickBtn.isEnabled = true
        goBtn.isEnabled = src != null
        progressBar.visibility = View.GONE
        progressText.text = message
        resultBox.removeAllViews()
        if (uri != null) {
            val play = Ui.button(this, "Ansehen", false) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "video/mp4")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    })
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this, "Keine App zum Abspielen gefunden.", Toast.LENGTH_LONG).show()
                }
            }
            val share = Ui.button(this, "Teilen", false) {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "Teilen mit"))
            }
            play.textSize = 14f
            share.textSize = 14f
            resultBox.addView(play, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
            resultBox.addView(share, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        }
    }
}
