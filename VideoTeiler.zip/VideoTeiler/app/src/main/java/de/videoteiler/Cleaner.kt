package de.videoteiler

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer

/** Packt ein Video ohne Neuberechnung in eine neue Datei um. Dabei gehen Standort, Gerätename und ähnliche Zusatzangaben verloren. */
object Cleaner {

    /** Gibt es im Video Standortdaten? */
    fun hasLocation(ctx: Context, uri: Uri): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            !r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_LOCATION).isNullOrBlank()
        } catch (e: Exception) {
            false
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }

    fun hasLocation(file: File): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            !r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_LOCATION).isNullOrBlank()
        } catch (e: Exception) {
            false
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }

    fun clean(ctx: Context, src: Uri, out: File) {
        if (out.exists()) out.delete()
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(ctx, src, null)
            var rotation = 0
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, src)
                rotation = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            } finally {
                r.release()
            }
            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            val map = HashMap<Int, Int>()
            var maxSize = 1 shl 20
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                val ok = (mime.startsWith("video/") && mime in Splitter.REMUX_VIDEO) ||
                    (mime.startsWith("audio/") && mime in setOf("audio/mp4a-latm", "audio/3gpp", "audio/amr-wb"))
                if (!ok) continue
                map[i] = m.addTrack(f)
                ex.selectTrack(i)
                if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) maxSize = maxOf(maxSize, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
            }
            if (map.isEmpty()) throw IllegalStateException("Dieses Videoformat lässt sich nicht verlustfrei umpacken.")
            m.setOrientationHint(rotation)
            m.start()
            started = true
            val buf = ByteBuffer.allocateDirect(maxSize + 1024)
            val info = MediaCodec.BufferInfo()
            var written = 0
            while (true) {
                val ti = ex.sampleTrackIndex
                if (ti < 0) break
                val dst = map[ti]
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                if (dst != null) {
                    val flags = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    info.set(0, size, ex.sampleTime, flags)
                    m.writeSampleData(dst, buf, info)
                    written++
                }
                ex.advance()
            }
            if (written == 0) throw IllegalStateException("Leeres Ergebnis.")
            try {
                m.stop()
            } finally {
                started = false
            }
        } finally {
            try { if (started) muxer?.stop() } catch (e: Exception) { }
            try { muxer?.release() } catch (e: Exception) { }
            ex.release()
        }
    }
}
