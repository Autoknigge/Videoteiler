package de.videoteiler

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.Effect
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Crop
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.Effects
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

/**
 * Wandelt ein Video (oder einen Abschnitt davon, wenn [endMs] > 0) nach H.264/AAC um (für Formate wie VP9, die sich nicht
 * einfach umpacken lassen). Muss im Hauptthread aufgerufen werden; die Rückmeldungen kommen dort an.
 */
object Transcoder {

    fun run(
        ctx: Context,
        src: Uri,
        out: File,
        startMs: Long,
        endMs: Long,
        onProgress: (Int) -> Unit,
        onDone: (String?) -> Unit,
        removeVideo: Boolean = false,
        removeAudio: Boolean = false,
        targetHeight: Int = 0,
        videoBitrate: Int = 0,
        speed: Float = 1f
    ) {
        if (out.exists()) out.delete()
        val itemBuilder = MediaItem.Builder().setUri(src)
        if (endMs > 0L || startMs > 0L) {
            val cb = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs)
            if (endMs > 0L) cb.setEndPositionMs(endMs)
            itemBuilder.setClippingConfiguration(cb.build())
        }
        val eb = EditedMediaItem.Builder(itemBuilder.build())
            .setRemoveVideo(removeVideo)
            .setRemoveAudio(removeAudio)
        val audioFx = ArrayList<AudioProcessor>()
        val videoFx = ArrayList<Effect>()
        if (speed != 1f) {
            // Ton und Bild gleichmäßig langsamer oder schneller machen (Tonhöhe bleibt gleich).
            audioFx.add(SonicAudioProcessor().apply { setSpeed(speed) })
            videoFx.add(SpeedChangeEffect(speed))
        }
        if (targetHeight > 0) videoFx.add(Presentation.createForHeight(targetHeight))
        if (audioFx.isNotEmpty() || videoFx.isNotEmpty()) eb.setEffects(Effects(audioFx, videoFx))
        val edited = eb.build()
        val handler = Handler(Looper.getMainLooper())
        var finished = false
        var transformer: Transformer? = null

        val poll = object : Runnable {
            override fun run() {
                if (finished) return
                val ph = ProgressHolder()
                val tr = transformer
                if (tr != null && tr.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(ph.progress)
                }
                handler.postDelayed(this, 500)
            }
        }

        val tb = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
        if (videoBitrate > 0) {
            tb.setEncoderFactory(
                DefaultEncoderFactory.Builder(ctx)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(videoBitrate).build())
                    .build()
            )
        }
        val tr = tb
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    finished = true
                    onDone(null)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    finished = true
                    onDone("Umwandlung fehlgeschlagen (${exportException.errorCode}): ${exportException.message}")
                }
            })
            .build()
        transformer = tr
        tr.start(edited, out.absolutePath)
        handler.postDelayed(poll, 500)
    }

    /**
     * Hängt mehrere Videos hintereinander und rechnet sie auf [width]×[height] (mit schwarzen Rändern, falls das
     * Seitenverhältnis abweicht). Mit [removeAudio] bleibt nur das Bild. Muss im Hauptthread aufgerufen werden.
     */
    fun concat(
        ctx: Context,
        srcs: List<Uri>,
        out: File,
        width: Int,
        height: Int,
        videoBitrate: Int,
        removeAudio: Boolean,
        onProgress: (Int) -> Unit,
        onDone: (String?) -> Unit
    ) {
        if (out.exists()) out.delete()
        val seq = EditedMediaItemSequence.Builder()
        for (u in srcs) {
            val eb = EditedMediaItem.Builder(MediaItem.fromUri(u))
                .setRemoveAudio(removeAudio)
                .setEffects(
                    Effects(
                        emptyList(),
                        listOf<Effect>(Presentation.createForWidthAndHeight(width, height, Presentation.LAYOUT_SCALE_TO_FIT))
                    )
                )
            seq.addItem(eb.build())
        }
        val composition = Composition.Builder(listOf(seq.build())).build()
        val handler = Handler(Looper.getMainLooper())
        var finished = false
        var transformer: Transformer? = null
        val poll = object : Runnable {
            override fun run() {
                if (finished) return
                val ph = ProgressHolder()
                val tr = transformer
                if (tr != null && tr.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(ph.progress)
                handler.postDelayed(this, 500)
            }
        }
        val tb = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(
                DefaultEncoderFactory.Builder(ctx)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(videoBitrate).build())
                    .build()
            )
        val tr = tb
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    finished = true
                    onDone(null)
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    finished = true
                    onDone("Umwandlung fehlgeschlagen (${exportException.errorCode}): ${exportException.message}")
                }
            })
            .build()
        transformer = tr
        tr.start(composition, out.absolutePath)
        handler.postDelayed(poll, 500)
    }

    /**
     * Dreht ein Video um [rotateCw] Grad im Uhrzeigersinn (0/90/180/270), schneidet optional mit [crop] (links, rechts, unten, oben
     * in Werten von -1 bis 1) und rechnet auf [outW]×[outH] (mit schwarzen Rändern, wenn das Seitenverhältnis abweicht).
     * Ist [outW] oder [outH] 0, wird nur auf die Höhe [outH] bzw. gar nicht skaliert. Muss im Hauptthread aufgerufen werden.
     */
    fun reframe(
        ctx: Context,
        src: Uri,
        out: File,
        rotateCw: Int,
        crop: FloatArray?,
        outW: Int,
        outH: Int,
        videoBitrate: Int,
        onProgress: (Int) -> Unit,
        onDone: (String?) -> Unit
    ) {
        if (out.exists()) out.delete()
        val fx = ArrayList<Effect>()
        if (rotateCw % 360 != 0) {
            fx.add(ScaleAndRotateTransformation.Builder().setRotationDegrees(-rotateCw.toFloat()).build())
        }
        if (crop != null) fx.add(Crop(crop[0], crop[1], crop[2], crop[3]))
        if (outW > 0 && outH > 0) {
            fx.add(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT))
        } else if (outH > 0) {
            fx.add(Presentation.createForHeight(outH))
        }
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(src))
            .setEffects(Effects(emptyList(), fx))
            .build()
        val handler = Handler(Looper.getMainLooper())
        var finished = false
        var transformer: Transformer? = null
        val poll = object : Runnable {
            override fun run() {
                if (finished) return
                val ph = ProgressHolder()
                val tr = transformer
                if (tr != null && tr.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(ph.progress)
                handler.postDelayed(this, 500)
            }
        }
        val tr = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(
                DefaultEncoderFactory.Builder(ctx)
                    .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(videoBitrate).build())
                    .build()
            )
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    finished = true
                    onDone(null)
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    finished = true
                    onDone("Umwandlung fehlgeschlagen (${exportException.errorCode}): ${exportException.message}")
                }
            })
            .build()
        transformer = tr
        tr.start(edited, out.absolutePath)
        handler.postDelayed(poll, 500)
    }
}
