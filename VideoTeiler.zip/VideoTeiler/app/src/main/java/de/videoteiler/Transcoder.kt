package de.videoteiler

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

/**
 * Wandelt ein Video (oder einen Abschnitt davon, wenn [endMs] > 0) nach H.264/AAC um (für Formate wie VP9, die sich nicht
 * einfach umpacken lassen). Muss im Hauptthread aufgerufen werden; die Rückmeldungen kommen dort an.
 */
object Transcoder {

    fun run(
        ctx: Context,
        src: Uri,
        out: File,
        startMs: Long,
        endMs: Long,
        onProgress: (Int) -> Unit,
        onDone: (String?) -> Unit,
        removeVideo: Boolean = false,
        removeAudio: Boolean = false
    ) {
        if (out.exists()) out.delete()
        val itemBuilder = MediaItem.Builder().setUri(src)
        if (endMs > 0L || startMs > 0L) {
            val cb = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs)
            if (endMs > 0L) cb.setEndPositionMs(endMs)
            itemBuilder.setClippingConfiguration(cb.build())
        }
        val edited = EditedMediaItem.Builder(itemBuilder.build())
            .setRemoveVideo(removeVideo)
            .setRemoveAudio(removeAudio)
            .build()
        val handler = Handler(Looper.getMainLooper())
        var finished = false
        var transformer: Transformer? = null

        val poll = object : Runnable {
            override fun run() {
                if (finished) return
                val ph = ProgressHolder()
                val tr = transformer
                if (tr != null && tr.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(ph.progress)
                }
                handler.postDelayed(this, 500)
            }
        }

        val tr = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    finished = true
                    onDone(null)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    finished = true
                    onDone("Umwandlung fehlgeschlagen (${exportException.errorCode}): ${exportException.message}")
                }
            })
            .build()
        transformer = tr
        tr.start(edited, out.absolutePath)
        handler.postDelayed(poll, 500)
    }
}
