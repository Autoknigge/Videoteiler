package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.VideoView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Holt die Tonspur eines Videos und speichert sie als m4a-Datei unter Musik/Video-Teiler. */
class AudioActivity : Activity() {

    private val REQ = 51
    private val main = Handler(Looper.getMainLooper())
    private var src: Uri? = null
    private var info: SourceInfo? = null
    private var busy = false
    private var result: Uri? = null

    private lateinit var infoText: TextView
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var pickBtn: Button
    private lateinit var goBtn: Button
    private lateinit var resultBox: LinearLayout
    private lateinit var sliderBox: LinearLayout
    private lateinit var startLabel: TextView
    private lateinit var endLabel: TextView
    private lateinit var lenLabel: TextView
    private lateinit var startBar: SeekBar
    private lateinit var endBar: SeekBar
    private lateinit var videoView: VideoView
    private var durSec = 0
    private var startSec = 0
    private var endSec = 0
    private var fixing = false
    private var playing = false
    private val ticker = object : Runnable {
        override fun run() {
            if (!playing) return
            if (videoView.currentPosition >= endSec * 1000) stopPlay() else main.postDelayed(this, 100)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        top.addView(Ui.header(this, "Tonspur aus Video kopieren", "Speichert den Ton als Audiodatei (m4a).", Ui.TILE_BROWN),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        pickBtn = Ui.button(this, "Video auswählen", true) { Ui.pickVideo(this, REQ) }
        top.addView(pickBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        infoText = Ui.text(this, "Noch kein Video gewählt.", 15f, Ui.INK, false)
        Ui.panel(this, infoText)
        infoText.setOnClickListener { if (src != null) togglePlay() }
        top.addView(infoText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })

        sliderBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        Ui.panel(this, sliderBox)
        sliderBox.addView(Ui.text(this, "Tippe oben auf den Dateinamen für eine Vorschau. Mit den Schiebern grenzt du den Teil ein, dessen Ton gespeichert wird.", 13f, Ui.MUTED, false))
        startLabel = Ui.text(this, "Anfang: 0:00", 15f, Ui.INK, true)
        sliderBox.addView(startLabel, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(8) })
        startBar = bar { v -> onStartChanged(v) }
        sliderBox.addView(startBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        endLabel = Ui.text(this, "Ende: 0:00", 15f, Ui.INK, true)
        sliderBox.addView(endLabel, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(8) })
        endBar = bar { v -> onEndChanged(v) }
        sliderBox.addView(endBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        lenLabel = Ui.text(this, "", 13f, Ui.MUTED, false)
        sliderBox.addView(lenLabel, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(6) })
        videoView = VideoView(this).apply { visibility = View.GONE }
        sliderBox.addView(videoView, LinearLayout.LayoutParams(Ui.MATCH, dp(220)).apply { topMargin = dp(8) })
        top.addView(sliderBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        goBtn = Ui.button(this, "Ton speichern", true) { start() }
        goBtn.isEnabled = false
        top.addView(goBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })

        progressText = Ui.text(this, "", 13f, Ui.MUTED, false)
        top.addView(progressText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            visibility = View.GONE
        }
        top.addView(progressBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        resultBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(resultBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        val scroll = android.widget.ScrollView(this)
        scroll.addView(top, android.view.ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
        Ui.incomingVideo(this)?.let { u -> window.decorView.post { onActivityResult(REQ, RESULT_OK, Intent().setData(u)) } }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                info = Splitter.readInfo(this, uri)
                src = uri
                stopPlay()
                durSec = (info!!.durationUs / 1_000_000L).toInt()
                infoText.text = "${info!!.name}\nLänge ${Ui.fmt(durSec.toLong())} Min.\n▶ Tippen für Vorschau"
                startSec = 0
                endSec = durSec
                if (durSec >= 2) {
                    fixing = true
                    startBar.max = durSec
                    endBar.max = durSec
                    startBar.progress = 0
                    endBar.progress = durSec
                    fixing = false
                    labels()
                    sliderBox.visibility = View.VISIBLE
                } else {
                    sliderBox.visibility = View.GONE
                }
                goBtn.isEnabled = true
            } catch (e: Exception) {
                src = null
                info = null
                sliderBox.visibility = View.GONE
                goBtn.isEnabled = false
                infoText.text = "Dieses Video konnte nicht gelesen werden."
            }
            resultBox.removeAllViews()
            progressText.text = ""
        }
    }

    private fun start() {
        val uri = src ?: return
        val inf = info ?: return
        if (busy) return
        stopPlay()
        busy = true
        pickBtn.isEnabled = false
        goBtn.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        resultBox.removeAllViews()
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = false
        progressBar.max = 100
        progressBar.progress = 0
        progressText.text = "Hole den Ton …"

        val base = inf.name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
            .trim('_')
            .take(40)
            .ifEmpty { "Ton" }
        val trimmed = durSec >= 2 && (startSec > 0 || endSec < durSec)
        val outName = if (trimmed) base + "_Ausschnitt" else base
        val tmp = File(cacheDir, "ton.tmp.m4a")
        val app = applicationContext

        Transcoder.run(this, uri, tmp, if (trimmed) startSec * 1000L else 0L, if (trimmed) endSec * 1000L else 0L,
            onProgress = { pct -> progressBar.progress = pct },
            onDone = { err ->
                if (err != null) {
                    tmp.delete()
                    showDone(null, "Fehler: $err (hat das Video einen Ton?)")
                } else {
                    Thread {
                        var out: Uri? = null
                        var msg: String? = null
                        try {
                            out = Splitter.createAudioOutput(app, "$outName.m4a")
                            Splitter.copyToGallery(app, tmp, out)
                            Splitter.finish(app, out)
                        } catch (e: Exception) {
                            msg = "Fehler: ${e.message ?: e.javaClass.simpleName}"
                            out?.let { Splitter.discard(app, it) }
                            out = null
                        }
                        tmp.delete()
                        val done = out
                        val m = msg
                        main.post { showDone(done, m ?: "Fertig: $outName.m4a in Musik/Video-Teiler gespeichert.") }
                    }.start()
                }
            },
            removeVideo = true
        )
    }

    private fun bar(onChange: (Int) -> Unit): SeekBar = SeekBar(this).apply {
        progressTintList = ColorStateList.valueOf(Ui.ACCENT)
        thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fixing) onChange(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    private fun onStartChanged(v: Int) {
        if (playing) stopPlay()
        startSec = v
        if (endSec <= startSec) {
            endSec = minOf(durSec, startSec + 1)
            fixing = true
            endBar.progress = endSec
            fixing = false
        }
        labels()
    }

    private fun onEndChanged(v: Int) {
        if (playing) stopPlay()
        endSec = v
        if (startSec >= endSec) {
            startSec = maxOf(0, endSec - 1)
            fixing = true
            startBar.progress = startSec
            fixing = false
        }
        labels()
    }

    private fun labels() {
        startLabel.text = "Anfang: ${Ui.fmt(startSec.toLong())}"
        endLabel.text = "Ende: ${Ui.fmt(endSec.toLong())}"
        lenLabel.text = "Länge des Ausschnitts: ${Ui.fmt((endSec - startSec).toLong())}"
    }

    /** Vorschau: spielt den gewählten Teil (mit Ton) in einem kleinen Fenster ab. */
    private fun togglePlay() {
        if (busy) return
        if (playing) stopPlay() else startPlay()
    }

    private fun startPlay() {
        val u = src ?: return
        val from = if (durSec >= 2) startSec else 0
        videoView.visibility = View.VISIBLE
        videoView.setOnPreparedListener { _ ->
            videoView.seekTo(from * 1000)
            videoView.start()
            playing = true
            main.removeCallbacks(ticker)
            main.postDelayed(ticker, 100)
        }
        videoView.setOnCompletionListener { stopPlay() }
        videoView.setOnErrorListener { _, _, _ ->
            stopPlay()
            Toast.makeText(this, "Das Video lässt sich hier nicht abspielen.", Toast.LENGTH_LONG).show()
            true
        }
        videoView.setVideoURI(u)
    }

    private fun stopPlay() {
        playing = false
        main.removeCallbacks(ticker)
        if (!::videoView.isInitialized) return
        try {
            videoView.stopPlayback()
        } catch (e: Exception) {
            // egal
        }
        videoView.visibility = View.GONE
    }

    override fun onPause() {
        if (playing) stopPlay()
        super.onPause()
    }

    private fun showDone(uri: Uri?, message: String) {
        busy = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        pickBtn.isEnabled = true
        goBtn.isEnabled = src != null
        progressBar.visibility = View.GONE
        progressText.text = message
        result = uri
        resultBox.removeAllViews()
        if (uri != null) {
            val play = Ui.button(this, "Anhören", false) { Player.open(this, uri, "audio/mp4") }
            val pick = Player.button(this, uri, "audio/mp4")
            val share = Ui.button(this, "Teilen", false) { share(uri) }
            play.textSize = 14f
            share.textSize = 14f
            resultBox.addView(play, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
            resultBox.addView(share, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
            resultBox.addView(pick, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        }
    }

    private fun open(uri: Uri) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "audio/mp4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Keine App zum Abspielen gefunden.", Toast.LENGTH_LONG).show()
        }
    }

    private fun share(uri: Uri) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "audio/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(i, "Teilen mit"))
    }
}
