package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Holt die Tonspur eines Videos und speichert sie als m4a-Datei unter Musik/Video-Teiler. */
class AudioActivity : Activity() {

    private val REQ = 51
    private val main = Handler(Looper.getMainLooper())
    private var src: Uri? = null
    private var info: SourceInfo? = null
    private var busy = false
    private var result: Uri? = null

    private lateinit var infoText: TextView
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var pickBtn: Button
    private lateinit var goBtn: Button
    private lateinit var resultBox: LinearLayout

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        top.addView(Ui.header(this, "Ton aus Video holen", "Speichert die Tonspur als Audiodatei (m4a)."),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        pickBtn = Ui.button(this, "Video auswählen", true) { Ui.pickVideo(this, REQ) }
        top.addView(pickBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        infoText = Ui.text(this, "Noch kein Video gewählt.", 15f, Ui.INK, false)
        Ui.panel(this, infoText)
        top.addView(infoText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })

        goBtn = Ui.button(this, "Ton speichern", true) { start() }
        goBtn.isEnabled = false
        top.addView(goBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })

        progressText = Ui.text(this, "", 13f, Ui.MUTED, false)
        top.addView(progressText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            visibility = View.GONE
        }
        top.addView(progressBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        resultBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(resultBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                info = Splitter.readInfo(this, uri)
                src = uri
                infoText.text = "${info!!.name}\nLänge ${Ui.fmt(info!!.durationUs / 1_000_000L)} Min."
                goBtn.isEnabled = true
            } catch (e: Exception) {
                src = null
                info = null
                goBtn.isEnabled = false
                infoText.text = "Dieses Video konnte nicht gelesen werden."
            }
            resultBox.removeAllViews()
            progressText.text = ""
        }
    }

    private fun start() {
        val uri = src ?: return
        val inf = info ?: return
        if (busy) return
        busy = true
        pickBtn.isEnabled = false
        goBtn.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        resultBox.removeAllViews()
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = false
        progressBar.max = 100
        progressBar.progress = 0
        progressText.text = "Hole den Ton …"

        val base = inf.name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
            .trim('_')
            .take(40)
            .ifEmpty { "Ton" }
        val tmp = File(cacheDir, "ton.tmp.m4a")
        val app = applicationContext

        Transcoder.run(this, uri, tmp, 0L, 0L,
            onProgress = { pct -> progressBar.progress = pct },
            onDone = { err ->
                if (err != null) {
                    tmp.delete()
                    showDone(null, "Fehler: $err (hat das Video einen Ton?)")
                } else {
                    Thread {
                        var out: Uri? = null
                        var msg: String? = null
                        try {
                            out = Splitter.createAudioOutput(app, "$base.m4a")
                            Splitter.copyToGallery(app, tmp, out)
                            Splitter.finish(app, out)
                        } catch (e: Exception) {
                            msg = "Fehler: ${e.message ?: e.javaClass.simpleName}"
                            out?.let { Splitter.discard(app, it) }
                            out = null
                        }
                        tmp.delete()
                        val done = out
                        val m = msg
                        main.post { showDone(done, m ?: "Fertig: $base.m4a in Musik/Video-Teiler gespeichert.") }
                    }.start()
                }
            },
            removeVideo = true
        )
    }

    private fun showDone(uri: Uri?, message: String) {
        busy = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        pickBtn.isEnabled = true
        goBtn.isEnabled = src != null
        progressBar.visibility = View.GONE
        progressText.text = message
        result = uri
        resultBox.removeAllViews()
        if (uri != null) {
            val play = Ui.button(this, "Anhören", false) { open(uri) }
            val share = Ui.button(this, "Teilen", false) { share(uri) }
            play.textSize = 14f
            share.textSize = 14f
            resultBox.addView(play, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
            resultBox.addView(share, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        }
    }

    private fun open(uri: Uri) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "audio/mp4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Keine App zum Abspielen gefunden.", Toast.LENGTH_LONG).show()
        }
    }

    private fun share(uri: Uri) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "audio/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(i, "Teilen mit"))
    }
}
