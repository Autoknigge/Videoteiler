package de.videoteiler

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.MediaStore
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Gemeinsame Farben und kleine Bausteine für die Bildschirme. */
object Ui {
    val BG = Color.parseColor("#0D1218")
    val SURFACE = Color.parseColor("#18212B")
    val INK = Color.parseColor("#E7ECF2")
    val MUTED = Color.parseColor("#9AA7B6")
    val ACCENT = Color.parseColor("#00A884")
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun round(ctx: Context, color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(ctx, radiusDp).toFloat()
        }

    fun text(ctx: Context, s: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(ctx).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun button(ctx: Context, label: String, primary: Boolean, onClick: () -> Unit): Button =
        Button(ctx).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setTextColor(if (primary) Color.WHITE else INK)
            background = round(ctx, if (primary) ACCENT else SURFACE, 12)
            setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
            setOnClickListener { onClick() }
        }

    /** Wurzelansicht mit Hintergrund und Abständen für die Systemleisten (Android 15/16). */
    fun root(a: Activity): LinearLayout {
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        root.setOnApplyWindowInsetsListener { v, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsets.CONSUMED
        }
        return root
    }

    fun bars(a: Activity) {
        a.window.statusBarColor = BG
        a.window.navigationBarColor = BG
        a.window.insetsController?.setSystemBarsAppearance(
            0,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )
    }

    /** Öffnet die Foto-Auswahl (zeigt die Länge der Videos); sonst die normale Dateiauswahl. */
    fun pickVideo(a: Activity, req: Int) {
        try {
            val photo = Intent(MediaStore.ACTION_PICK_IMAGES).apply { type = "video/*" }
            @Suppress("DEPRECATION")
            a.startActivityForResult(photo, req)
            return
        } catch (e: Exception) {
            // weiter mit der Dateiauswahl
        }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        @Suppress("DEPRECATION")
        a.startActivityForResult(i, req)
    }

    fun pickAudio(a: Activity, req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*"))
        }
        @Suppress("DEPRECATION")
        a.startActivityForResult(i, req)
    }

    fun fmt(sec: Long): String = "%d:%02d".format(sec / 60, sec % 60)
}
