package de.videoteiler

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.MotionEvent
import android.view.View
import android.provider.MediaStore
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Gemeinsame Farben und kleine Bausteine für die Bildschirme. */
object Ui {
    // Grün mit Gold: tiefes Waldgrün als Hintergrund, goldene Überschriften, cremefarbener Text.
    val BG_TOP = Color.parseColor("#1A4030")
    val BG_BOTTOM = Color.parseColor("#071811")
    val BG = Color.parseColor("#142C1F")
    val SURFACE = Color.parseColor("#16422F")
    val SURFACE2 = Color.parseColor("#1F5A40")

    // Erdtöne für die Schaltkacheln: Füllfarbe, Titelfarbe, Textfarbe (alle gut lesbar).
    class TileColors(val fill: Int, val title: Int, val text: Int)
    val TILE_YELLOW = TileColors(Color.parseColor("#D49A1C"), Color.parseColor("#2A1A06"), Color.parseColor("#3A2509"))
    val TILE_ORANGE = TileColors(Color.parseColor("#C8601E"), Color.parseColor("#2B1204"), Color.parseColor("#3D1B07"))
    val TILE_OCKER = TileColors(Color.parseColor("#D49A1C"), Color.parseColor("#2A1A06"), Color.parseColor("#3A2509"))
    val TILE_RED = TileColors(Color.parseColor("#9E3A28"), Color.parseColor("#FFE9A0"), Color.parseColor("#FFDC94"))
    val TILE_BROWN = TileColors(Color.parseColor("#6B4226"), Color.parseColor("#FFE9A0"), Color.parseColor("#FFDC94"))
    val TILE_OLIVE = TileColors(Color.parseColor("#5C6B1E"), Color.parseColor("#FFE9A0"), Color.parseColor("#FFE9A0"))
    val INK = Color.parseColor("#FFE27A")
    val MUTED = Color.parseColor("#E6C566")
    val GOLD = Color.parseColor("#FFCF4A")
    val ACCENT = Color.parseColor("#FFCF4A")
    val ON_ACCENT = Color.parseColor("#0A3B2A")
    val LINE = Color.parseColor("#66FFCF4A")
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun round(ctx: Context, color: Int, radiusDp: Int, stroke: Boolean = true): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(ctx, radiusDp).toFloat()
            if (stroke) setStroke(dp(ctx, 1), LINE)
        }

    private fun shade(c: Int, f: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[2] = (hsv[2] * f).coerceIn(0f, 1f)
        if (f > 1f) hsv[1] = (hsv[1] / f.coerceAtLeast(1f)).coerceIn(0f, 1f)
        return Color.HSVToColor(hsv)
    }

    /** Kachel mit 3D-Rand: Schatten, goldener Rahmen (hell oben links, dunkel unten rechts) und gewölbte Fläche. */
    fun tile3d(ctx: Context, fill: Int, faceColors: IntArray? = null, radiusDp: Int = 18): LayerDrawable {
        val r = dp(ctx, radiusDp).toFloat()
        val shadow = GradientDrawable().apply { setColor(Color.parseColor("#80000000")); cornerRadius = r }
        val rim = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#F6DE92"), Color.parseColor("#C79A2E"), Color.parseColor("#4A2E10"))
        ).apply { cornerRadius = r }
        val face = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            faceColors ?: intArrayOf(shade(fill, 1.4f), shade(fill, 1.1f), shade(fill, 0.85f), shade(fill, 0.55f))
        ).apply { cornerRadius = r - dp(ctx, 3) }
        val ld = LayerDrawable(arrayOf(shadow, rim, face))
        ld.setLayerInset(0, dp(ctx, 3), dp(ctx, 6), 0, 0)
        ld.setLayerInset(1, 0, 0, dp(ctx, 3), dp(ctx, 6))
        ld.setLayerInset(2, dp(ctx, 3), dp(ctx, 3), dp(ctx, 6), dp(ctx, 9))
        return ld
    }

    /** Kachel drückt sich beim Antippen ein Stück nach unten. */
    fun pressEffect(ctx: Context, v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> view.translationY = dp(ctx, 3).toFloat()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.translationY = 0f
            }
            false
        }
    }

    /** Werbebanner am Fuß des Bildschirms (Gratis- und Start-Ausgabe); Pro: nichts. */
    fun adFooter(a: Activity, root: LinearLayout) {
        if (!Ads.enabled) return
        var hasWeight = false
        for (i in 0 until root.childCount) {
            val lp = root.getChildAt(i).layoutParams as? LinearLayout.LayoutParams
            if (lp != null && lp.weight > 0f) hasWeight = true
        }
        // Der Banner soll ganz unten sitzen: ohne dehnbaren Inhalt einen Abstandshalter einfügen.
        if (!hasWeight) root.addView(View(a), LinearLayout.LayoutParams(MATCH, 0, 1f))
        Ads.attach(a, root)
    }

    /** Hintergrund mit sanftem Verlauf von oben nach unten. */
    fun gradient(): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(BG_TOP, BG_BOTTOM))

    fun text(ctx: Context, s: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(ctx).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) {
                // Moderne, kräftige Schrift für Überschriften und Knöpfe.
                setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD))
            }
        }

    val GOLD_FACE = intArrayOf(Color.parseColor("#FFF0A8"), Color.parseColor("#FFCF4A"), Color.parseColor("#9A7220"))
    val GREEN_FACE = intArrayOf(Color.parseColor("#2C7A58"), Color.parseColor("#17513A"), Color.parseColor("#0B2C1F"))

    val PANEL_FACE = intArrayOf(Color.parseColor("#1D5039"), Color.parseColor("#12301F"), Color.parseColor("#0A1D14"))

    /** Dunkles 3D-Feld mit goldenem Rand für Textfelder und Listeneinträge. */
    fun panel(ctx: Context, v: View) {
        v.background = tile3d(ctx, BG, PANEL_FACE, 14)
        v.setPadding(dp(ctx, 17), dp(ctx, 13), dp(ctx, 20), dp(ctx, 20))
    }

    /** Kopf eines Werkzeug-Bildschirms in der Farbe der Kachel auf der Startseite (goldener 3D-Rand, Farbverlauf). */
    fun header(ctx: Context, title: String, sub: String, colors: TileColors): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            background = tile3d(ctx, colors.fill, null, 18)
            setPadding(dp(ctx, 21), dp(ctx, 14), dp(ctx, 24), dp(ctx, 20))
            addView(text(ctx, title, 20f, colors.title, true).apply { gravity = android.view.Gravity.CENTER })
            addView(text(ctx, sub, 13f, colors.text, false).apply { gravity = android.view.Gravity.CENTER },
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(ctx, 3) })
        }

    /** Macht aus einem Button einen 3D-Schaltknopf (golden = wichtig, grün = normal). */
    fun style3d(ctx: Context, b: Button, primary: Boolean, radiusDp: Int = 14) {
        b.isAllCaps = false
        b.setTextColor(if (primary) ON_ACCENT else INK)
        b.background = tile3d(ctx, if (primary) ACCENT else SURFACE, if (primary) GOLD_FACE else GREEN_FACE, radiusDp)
        b.setPadding(dp(ctx, 17), dp(ctx, 14), dp(ctx, 20), dp(ctx, 20))
        b.stateListAnimator = null
        pressEffect(ctx, b)
    }

    fun button(ctx: Context, label: String, primary: Boolean, onClick: () -> Unit): Button =
        Button(ctx).apply {
            text = label
            textSize = 16f
            style3d(ctx, this, primary)
            setOnClickListener { onClick() }
        }

    /** Wurzelansicht mit Hintergrund und Abständen für die Systemleisten (Android 15/16). */
    fun root(a: Activity): LinearLayout {
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = gradient()
        }
        root.setOnApplyWindowInsetsListener { v, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsets.CONSUMED
        }
        return root
    }

    fun bars(a: Activity) {
        a.window.statusBarColor = BG_TOP
        a.window.navigationBarColor = BG_BOTTOM
        a.window.insetsController?.setSystemBarsAppearance(
            0,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )
    }

    /** Öffnet die Foto-Auswahl (zeigt die Länge der Videos); sonst die normale Dateiauswahl. */
    fun pickVideo(a: Activity, req: Int) {
        try {
            val photo = Intent(MediaStore.ACTION_PICK_IMAGES).apply { type = "video/*" }
            @Suppress("DEPRECATION")
            a.startActivityForResult(photo, req)
            return
        } catch (e: Exception) {
            // weiter mit der Dateiauswahl
        }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        @Suppress("DEPRECATION")
        a.startActivityForResult(i, req)
    }

    fun pickAudio(a: Activity, req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*"))
        }
        @Suppress("DEPRECATION")
        a.startActivityForResult(i, req)
    }

    fun fmt(sec: Long): String = "%d:%02d".format(sec / 60, sec % 60)
}
