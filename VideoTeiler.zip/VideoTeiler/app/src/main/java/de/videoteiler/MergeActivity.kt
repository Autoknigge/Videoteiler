package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.media.MediaPlayer
import android.view.View
import android.widget.SeekBar
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Vertont ein Video mit einer Audiodatei. Der Originalton des Videos wird ersetzt. */
class MergeActivity : Activity() {

    private val REQ_VIDEO = 61
    private val REQ_AUDIO = 62
    private val main = Handler(Looper.getMainLooper())

    private var videoUri: Uri? = null
    private var videoInfo: SourceInfo? = null
    private var audioUri: Uri? = null
    private var audioInfo: SourceInfo? = null
    private var busy = false
    private var offsetSec = 0
    private var player: MediaPlayer? = null

    private lateinit var videoText: TextView
    private lateinit var audioText: TextView
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var pickVideoBtn: Button
    private lateinit var pickAudioBtn: Button
    private lateinit var goBtn: Button
    private lateinit var resultBox: LinearLayout
    private lateinit var slider: SeekBar
    private lateinit var sliderBox: LinearLayout
    private lateinit var sliderText: TextView
    private lateinit var previewBtn: Button

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        top.addView(Ui.header(this, "Video mit neuem Ton", "Der Originalton wird ersetzt. Das Ergebnis ist so lang wie das Video.", Ui.TILE_BROWN),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        pickVideoBtn = Ui.button(this, "1. Video auswählen", true) { Ui.pickVideo(this, REQ_VIDEO) }
        top.addView(pickVideoBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })
        videoText = box("Noch kein Video gewählt.")
        top.addView(videoText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        pickAudioBtn = Ui.button(this, "2. Audio auswählen", true) { Ui.pickAudio(this, REQ_AUDIO) }
        top.addView(pickAudioBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })
        audioText = box("Noch kein Audio gewählt.")
        top.addView(audioText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        // Schieber: ab welcher Stelle der Audiodatei der Ton beginnt
        sliderBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        Ui.panel(this, sliderBox)
        sliderText = Ui.text(this, "Ton beginnt bei 0:00", 15f, Ui.INK, true)
        sliderBox.addView(sliderText)
        sliderBox.addView(Ui.text(this, "Mit dem Schieber die Stelle im Ton wählen, die zum Video passt.", 12f, Ui.MUTED, false))
        slider = SeekBar(this).apply {
            max = 0
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    setOffset(progress)
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {
                    if (player != null) stopPreview()
                }
            })
        }
        sliderBox.addView(slider, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        val sliderRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val minus = Ui.button(this, "−1 s", false) { slider.progress = maxOf(0, slider.progress - 1) }
        previewBtn = Ui.button(this, "Anhören", false) { togglePreview() }
        val plus = Ui.button(this, "+1 s", false) { slider.progress = minOf(slider.max, slider.progress + 1) }
        for (b in listOf(minus, previewBtn, plus)) b.textSize = 14f
        sliderRow.addView(minus, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(6) })
        sliderRow.addView(previewBtn, LinearLayout.LayoutParams(0, Ui.WRAP, 1.4f).apply { rightMargin = dp(6) })
        sliderRow.addView(plus, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        sliderBox.addView(sliderRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        top.addView(sliderBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        goBtn = Ui.button(this, "Zusammenführen", true) { start() }
        goBtn.isEnabled = false
        top.addView(goBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(16) })

        progressText = Ui.text(this, "", 13f, Ui.MUTED, false)
        top.addView(progressText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            visibility = View.GONE
        }
        top.addView(progressBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        resultBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(resultBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
    }

    private fun box(s: String): TextView =
        Ui.text(this, s, 15f, Ui.INK, false).apply {
            Ui.panel(this@MergeActivity, this)
        }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val inf = Splitter.readInfo(this, uri)
            val line = "${inf.name}\nLänge ${Ui.fmt(inf.durationUs / 1_000_000L)} Min."
            if (requestCode == REQ_VIDEO) {
                videoUri = uri
                videoInfo = inf
                videoText.text = line
            } else if (requestCode == REQ_AUDIO) {
                audioUri = uri
                audioInfo = inf
                audioText.text = line
                stopPreview()
                val len = (inf.durationUs / 1_000_000L).toInt()
                slider.max = maxOf(0, len - 1)
                slider.progress = 0
                setOffset(0)
                sliderBox.visibility = if (len > 1) View.VISIBLE else View.GONE
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Diese Datei konnte nicht gelesen werden.", Toast.LENGTH_LONG).show()
        }
        goBtn.isEnabled = videoUri != null && audioUri != null && !busy
        resultBox.removeAllViews()
        progressText.text = ""
    }

    private fun setOffset(sec: Int) {
        offsetSec = sec
        val total = ((audioInfo?.durationUs ?: 0L) / 1_000_000L)
        sliderText.text = "Ton beginnt bei ${Ui.fmt(sec.toLong())} von ${Ui.fmt(total)}"
    }

    private fun togglePreview() {
        if (player != null) {
            stopPreview()
            return
        }
        val a = audioUri ?: return
        try {
            val mp = MediaPlayer()
            mp.setDataSource(this, a)
            mp.setOnPreparedListener {
                it.seekTo(offsetSec * 1000)
                it.start()
            }
            mp.setOnCompletionListener { stopPreview() }
            mp.setOnErrorListener { _, _, _ -> stopPreview(); true }
            mp.prepareAsync()
            player = mp
            previewBtn.text = "Stopp"
        } catch (e: Exception) {
            player = null
            Toast.makeText(this, "Der Ton lässt sich nicht abspielen.", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopPreview() {
        try {
            player?.release()
        } catch (e: Exception) {
            // egal
        }
        player = null
        if (::previewBtn.isInitialized) previewBtn.text = "Anhören"
    }

    override fun onPause() {
        stopPreview()
        super.onPause()
    }

    private fun setBusy(on: Boolean) {
        busy = on
        pickVideoBtn.isEnabled = !on
        pickAudioBtn.isEnabled = !on
        goBtn.isEnabled = !on && videoUri != null && audioUri != null
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun fail(msg: String) {
        setBusy(false)
        progressBar.visibility = View.GONE
        progressText.text = "Fehler: $msg"
    }

    private fun start() {
        val v = videoUri ?: return
        val a = audioUri ?: return
        val vi = videoInfo ?: return
        if (busy) return
        setBusy(true)
        resultBox.removeAllViews()
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = false
        progressBar.max = 100
        progressBar.progress = 0

        stopPreview()
        val base = vi.name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
            .trim('_')
            .take(40)
            .ifEmpty { "Video" }
        val tmpAudio = File(cacheDir, "merge.audio.m4a")
        val tmpVideo = File(cacheDir, "merge.video.mp4")
        val tmpOut = File(cacheDir, "merge.out.mp4")
        val app = applicationContext

        // Schritt 1: Ton nach AAC bringen (bei m4a/aac meist nur umpacken).
        progressText.text = if (offsetSec > 0) "Schneide den Ton ab ${Ui.fmt(offsetSec.toLong())} zu …" else "Bereite den Ton vor …"
        Transcoder.run(this, a, tmpAudio, offsetSec * 1000L, 0L,
            onProgress = { pct -> progressBar.progress = pct },
            onDone = { err ->
                if (err != null) {
                    cleanup(tmpAudio, tmpVideo, tmpOut)
                    fail("$err (hat die Datei einen Ton?)")
                } else {
                    prepareVideo(v, base, tmpAudio, tmpVideo, tmpOut, app)
                }
            },
            removeVideo = true
        )
    }

    private fun prepareVideo(v: Uri, base: String, tmpAudio: File, tmpVideo: File, tmpOut: File, app: android.content.Context) {
        Thread {
            var mime = ""
            var err: String? = null
            try {
                mime = Splitter.videoMime(app, v)
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
            }
            val m = mime
            val e0 = err
            main.post {
                if (e0 != null) {
                    cleanup(tmpAudio, tmpVideo, tmpOut)
                    fail(e0)
                } else if (m in Splitter.REMUX_VIDEO) {
                    mux(v, base, tmpAudio, tmpVideo, tmpOut, app)
                } else {
                    // Videoformat lässt sich nicht umpacken (zum Beispiel VP9): erst nach H.264 umwandeln.
                    progressText.text = "Wandle das Video um (dauert länger) …"
                    progressBar.progress = 0
                    Transcoder.run(this, v, tmpVideo, 0L, 0L,
                        onProgress = { pct -> progressBar.progress = pct },
                        onDone = { err2 ->
                            if (err2 != null) {
                                cleanup(tmpAudio, tmpVideo, tmpOut)
                                fail(err2)
                            } else {
                                mux(Uri.fromFile(tmpVideo), base, tmpAudio, tmpVideo, tmpOut, app)
                            }
                        },
                        removeAudio = true
                    )
                }
            }
        }.start()
    }

    private fun mux(videoSrc: Uri, base: String, tmpAudio: File, tmpVideo: File, tmpOut: File, app: android.content.Context) {
        progressBar.isIndeterminate = true
        progressText.text = "Füge Ton und Video zusammen …"
        Thread {
            var out: Uri? = null
            var err: String? = null
            try {
                Merger.mux(app, videoSrc, Uri.fromFile(tmpAudio), tmpOut)
                out = Splitter.createOutput(app, "${base}_neuer_Ton.mp4")
                Splitter.copyToGallery(app, tmpOut, out)
                Splitter.finish(app, out)
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
                out?.let { Splitter.discard(app, it) }
                out = null
            }
            cleanup(tmpAudio, tmpVideo, tmpOut)
            val done = out
            val e1 = err
            main.post {
                if (done == null) {
                    fail(e1 ?: "unbekannt")
                } else {
                    setBusy(false)
                    progressBar.visibility = View.GONE
                    progressText.text = "Fertig: ${base}_neuer_Ton.mp4 in Filme/Video-Teiler gespeichert."
                    showResult(done)
                }
            }
        }.start()
    }

    private fun cleanup(vararg files: File) {
        for (f in files) {
            try {
                f.delete()
            } catch (e: Exception) {
                // egal
            }
        }
    }

    private fun showResult(uri: Uri) {
        resultBox.removeAllViews()
        val play = Ui.button(this, "Ansehen", false) {
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startActivity(i)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this, "Keine App zum Abspielen gefunden.", Toast.LENGTH_LONG).show()
            }
        }
        val share = Ui.button(this, "Teilen", false) {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Teilen mit"))
        }
        play.textSize = 14f
        share.textSize = 14f
        resultBox.addView(play, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
        resultBox.addView(share, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
    }
}
