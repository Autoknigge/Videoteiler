package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.media.MediaPlayer
import android.view.View
import android.view.ViewGroup
import android.provider.MediaStore
import android.widget.SeekBar
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Hängt Videos hintereinander und/oder legt neuen Ton darüber. Ein einzelnes Video wird nur vertont (ohne Neuberechnung des Bildes). */
class MergeActivity : Activity() {

    private val REQ_VIDEO = 61
    private val REQ_AUDIO = 62
    private val main = Handler(Looper.getMainLooper())

    private class Clip(val uri: Uri, val info: SourceInfo)
    private val clips = ArrayList<Clip>()
    private var mode = 0 // 0 = Originalton, 1 = ohne Ton, 2 = neuer Ton
    private var quality = 0 // 0 = 480p, 1 = 720p, 2 = 1080p
    private var audioUri: Uri? = null
    private var audioInfo: SourceInfo? = null
    private var busy = false
    private var offsetSec = 0
    private var player: MediaPlayer? = null

    private lateinit var listBox: LinearLayout
    private lateinit var sumText: TextView
    private lateinit var modeBox: LinearLayout
    private lateinit var qualityBox: LinearLayout
    private lateinit var audioBox: LinearLayout
    private val modeBtns = ArrayList<Button>()
    private val qualityBtns = ArrayList<Button>()
    private lateinit var audioText: TextView
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var pickVideoBtn: Button
    private lateinit var pickAudioBtn: Button
    private lateinit var goBtn: Button
    private lateinit var resultBox: LinearLayout
    private lateinit var slider: SeekBar
    private lateinit var sliderBox: LinearLayout
    private lateinit var sliderText: TextView
    private lateinit var previewBtn: Button

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        top.addView(Ui.header(this, "Videos verbinden & Ton", "Mehrere Videos hintereinander, mit Originalton oder neuem Ton.", Ui.TILE_OLIVE),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        pickVideoBtn = Ui.button(this, "Videos auswählen", true) { pickVideos() }
        top.addView(pickVideoBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        top.addView(listBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        sumText = Ui.text(this, "", 13f, Ui.MUTED, false)
        top.addView(sumText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })

        // Ton: nur bei mehreren Videos wählbar
        modeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        modeBox.addView(Ui.text(this, "Ton", 15f, Ui.INK, true))
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val modeNames = listOf("Originalton", "Ohne Ton", "Neuer Ton")
        for ((i, n) in modeNames.withIndex()) {
            val bt = Ui.button(this, n, i == 0) { setMode(i) }
            bt.textSize = 13f
            modeBtns.add(bt)
            modeRow.addView(bt, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { if (i < 2) rightMargin = dp(6) })
        }
        modeBox.addView(modeRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        top.addView(modeBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        // Qualität: nur bei mehreren Videos (sie werden neu berechnet)
        qualityBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        qualityBox.addView(Ui.text(this, "Qualität", 15f, Ui.INK, true))
        val qRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val qNames = listOf("Klein 480p", "Mittel 720p", "Hoch 1080p")
        for ((i, n) in qNames.withIndex()) {
            val bt = Ui.button(this, n, i == 0) { setQuality(i) }
            bt.textSize = 13f
            qualityBtns.add(bt)
            qRow.addView(bt, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { if (i < 2) rightMargin = dp(6) })
        }
        qualityBox.addView(qRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        top.addView(qualityBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        audioBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pickAudioBtn = Ui.button(this, "Audio auswählen", true) { Ui.pickAudio(this, REQ_AUDIO) }
        audioBox.addView(pickAudioBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        audioText = box("Noch kein Audio gewählt.")
        audioBox.addView(audioText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        top.addView(audioBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        // Schieber: ab welcher Stelle der Audiodatei der Ton beginnt
        sliderBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        Ui.panel(this, sliderBox)
        sliderText = Ui.text(this, "Ton beginnt bei 0:00", 15f, Ui.INK, true)
        sliderBox.addView(sliderText)
        sliderBox.addView(Ui.text(this, "Mit dem Schieber die Stelle im Ton wählen, die zum Video passt.", 12f, Ui.MUTED, false))
        slider = SeekBar(this).apply {
            max = 0
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    setOffset(progress)
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {
                    if (player != null) stopPreview()
                }
            })
        }
        sliderBox.addView(slider, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        val sliderRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val minus = Ui.button(this, "−1 s", false) { slider.progress = maxOf(0, slider.progress - 1) }
        previewBtn = Ui.button(this, "Anhören", false) { togglePreview() }
        val plus = Ui.button(this, "+1 s", false) { slider.progress = minOf(slider.max, slider.progress + 1) }
        for (b in listOf(minus, previewBtn, plus)) b.textSize = 14f
        sliderRow.addView(minus, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(6) })
        sliderRow.addView(previewBtn, LinearLayout.LayoutParams(0, Ui.WRAP, 1.4f).apply { rightMargin = dp(6) })
        sliderRow.addView(plus, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        sliderBox.addView(sliderRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        audioBox.addView(sliderBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        goBtn = Ui.button(this, "Starten", true) { start() }
        goBtn.isEnabled = false
        top.addView(goBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(16) })

        progressText = Ui.text(this, "", 13f, Ui.MUTED, false)
        top.addView(progressText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            visibility = View.GONE
        }
        top.addView(progressBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        resultBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(resultBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        val scroll = android.widget.ScrollView(this)
        scroll.addView(top, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
        Ui.incomingVideo(this)?.let { u -> window.decorView.post { onActivityResult(REQ_VIDEO, RESULT_OK, Intent().setData(u)) } }
        refresh()
    }

    private fun pickVideos() {
        try {
            val i = Intent(MediaStore.ACTION_PICK_IMAGES).apply {
                type = "video/*"
                putExtra("android.provider.extra.PICK_IMAGES_MAX", 20)
            }
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_VIDEO)
            return
        } catch (e: Exception) {
            // weiter mit der Dateiauswahl
        }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_VIDEO)
    }

    private fun setMode(m: Int) {
        mode = m
        refresh()
    }

    private fun setQuality(q: Int) {
        quality = q
        refresh()
    }

    private fun styleChoice(list: List<Button>, sel: Int) {
        for ((i, b) in list.withIndex()) Ui.style3d(this, b, i == sel)
        for (b in list) b.textSize = 13f
    }

    /** Zeigt Liste, Auswahlfelder und Startknopf passend zum aktuellen Stand. */
    private fun refresh() {
        if (clips.size < 2) mode = 2
        listBox.removeAllViews()
        for ((i, c) in clips.withIndex()) listBox.addView(clipRow(i, c), LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        val totalSec = clips.sumOf { it.info.durationUs } / 1_000_000L
        sumText.text = when {
            clips.isEmpty() -> "Noch kein Video gewählt."
            clips.size == 1 -> "1 Video · ${Ui.fmt(totalSec)} Min. – der Originalton wird ersetzt."
            totalSec > 600 -> "${clips.size} Videos · zusammen ${Ui.fmt(totalSec)} Min. – das dauert lange und braucht viel Speicher."
            else -> "${clips.size} Videos · zusammen ${Ui.fmt(totalSec)} Min."
        }
        pickVideoBtn.text = if (clips.isEmpty()) "Videos auswählen" else "Weitere Videos hinzufügen"
        modeBox.visibility = if (clips.size >= 2) View.VISIBLE else View.GONE
        qualityBox.visibility = if (clips.size >= 2) View.VISIBLE else View.GONE
        audioBox.visibility = if (clips.isNotEmpty() && mode == 2) View.VISIBLE else View.GONE
        styleChoice(modeBtns, mode)
        styleChoice(qualityBtns, quality)
        goBtn.text = if (clips.size >= 2) "Videos verbinden" else "Ton einsetzen"
        goBtn.isEnabled = !busy && clips.isNotEmpty() && (mode != 2 || audioUri != null)
    }

    private fun clipRow(i: Int, c: Clip): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        Ui.panel(this, row)
        val t = Ui.text(this, "${i + 1}. ${c.info.name}\n${Ui.fmt(c.info.durationUs / 1_000_000L)} Min.", 13f, Ui.INK, false)
        row.addView(t, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        fun small(label: String, enabled: Boolean, act: () -> Unit): Button =
            Ui.button(this, label, false) { act() }.apply {
                textSize = 14f
                minWidth = 0
                minimumWidth = 0
                setPadding(dp(11), dp(6), dp(14), dp(12))
                isEnabled = enabled && !busy
            }
        if (clips.size >= 2) {
            row.addView(small("▲", i > 0) { move(i, -1) }, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { leftMargin = dp(4) })
            row.addView(small("▼", i < clips.size - 1) { move(i, 1) }, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { leftMargin = dp(4) })
        }
        row.addView(small("✕", true) { remove(i) }, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { leftMargin = dp(4) })
        return row
    }

    private fun move(i: Int, d: Int) {
        val j = i + d
        if (j < 0 || j >= clips.size) return
        val c = clips.removeAt(i)
        clips.add(j, c)
        resultBox.removeAllViews()
        refresh()
    }

    private fun remove(i: Int) {
        if (i in clips.indices) clips.removeAt(i)
        resultBox.removeAllViews()
        progressText.text = ""
        refresh()
    }

    private fun box(s: String): TextView =
        Ui.text(this, s, 15f, Ui.INK, false).apply {
            Ui.panel(this@MergeActivity, this)
        }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == REQ_VIDEO) {
            val uris = ArrayList<Uri>()
            val cd = data.clipData
            if (cd != null) for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
            else data.data?.let { uris.add(it) }
            var bad = 0
            for (u in uris) {
                try {
                    clips.add(Clip(u, Splitter.readInfo(this, u)))
                } catch (e: Exception) {
                    bad++
                }
            }
            if (bad > 0) Toast.makeText(this, "$bad Datei(en) konnten nicht gelesen werden.", Toast.LENGTH_LONG).show()
        } else if (requestCode == REQ_AUDIO) {
            val uri = data.data ?: return
            try {
                val inf = Splitter.readInfo(this, uri)
                audioUri = uri
                audioInfo = inf
                audioText.text = "${inf.name}\nLänge ${Ui.fmt(inf.durationUs / 1_000_000L)} Min."
                stopPreview()
                val len = (inf.durationUs / 1_000_000L).toInt()
                slider.max = maxOf(0, len - 1)
                slider.progress = 0
                setOffset(0)
                sliderBox.visibility = if (len > 1) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                Toast.makeText(this, "Diese Datei konnte nicht gelesen werden.", Toast.LENGTH_LONG).show()
            }
        }
        resultBox.removeAllViews()
        progressText.text = ""
        refresh()
    }

    private fun setOffset(sec: Int) {
        offsetSec = sec
        val total = ((audioInfo?.durationUs ?: 0L) / 1_000_000L)
        sliderText.text = "Ton beginnt bei ${Ui.fmt(sec.toLong())} von ${Ui.fmt(total)}"
    }

    private fun togglePreview() {
        if (player != null) {
            stopPreview()
            return
        }
        val a = audioUri ?: return
        try {
            val mp = MediaPlayer()
            mp.setDataSource(this, a)
            mp.setOnPreparedListener {
                it.seekTo(offsetSec * 1000)
                it.start()
            }
            mp.setOnCompletionListener { stopPreview() }
            mp.setOnErrorListener { _, _, _ -> stopPreview(); true }
            mp.prepareAsync()
            player = mp
            previewBtn.text = "Stopp"
        } catch (e: Exception) {
            player = null
            Toast.makeText(this, "Der Ton lässt sich nicht abspielen.", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopPreview() {
        try {
            player?.release()
        } catch (e: Exception) {
            // egal
        }
        player = null
        if (::previewBtn.isInitialized) previewBtn.text = "Anhören"
    }

    override fun onPause() {
        stopPreview()
        super.onPause()
    }

    private fun setBusy(on: Boolean) {
        busy = on
        pickVideoBtn.isEnabled = !on
        pickAudioBtn.isEnabled = !on
        refresh()
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun fail(msg: String) {
        setBusy(false)
        progressBar.visibility = View.GONE
        progressText.text = "Fehler: $msg"
    }

    private fun start() {
        if (busy || clips.isEmpty()) return
        if (clips.size >= 2) {
            startConcat()
            return
        }
        val v = clips[0].uri
        val a = audioUri ?: return
        val vi = clips[0].info
        setBusy(true)
        resultBox.removeAllViews()
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = false
        progressBar.max = 100
        progressBar.progress = 0

        stopPreview()
        val base = vi.name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
            .trim('_')
            .take(40)
            .ifEmpty { "Video" }
        val tmpAudio = File(cacheDir, "merge.audio.m4a")
        val tmpVideo = File(cacheDir, "merge.video.mp4")
        val tmpOut = File(cacheDir, "merge.out.mp4")
        val app = applicationContext

        // Schritt 1: Ton nach AAC bringen (bei m4a/aac meist nur umpacken).
        progressText.text = if (offsetSec > 0) "Schneide den Ton ab ${Ui.fmt(offsetSec.toLong())} zu …" else "Bereite den Ton vor …"
        Transcoder.run(this, a, tmpAudio, offsetSec * 1000L, 0L,
            onProgress = { pct -> progressBar.progress = pct },
            onDone = { err ->
                if (err != null) {
                    cleanup(tmpAudio, tmpVideo, tmpOut)
                    fail("$err (hat die Datei einen Ton?)")
                } else {
                    prepareVideo(v, base, tmpAudio, tmpVideo, tmpOut, app)
                }
            },
            removeVideo = true
        )
    }

    private fun prepareVideo(v: Uri, base: String, tmpAudio: File, tmpVideo: File, tmpOut: File, app: android.content.Context) {
        Thread {
            var mime = ""
            var err: String? = null
            try {
                mime = Splitter.videoMime(app, v)
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
            }
            val m = mime
            val e0 = err
            main.post {
                if (e0 != null) {
                    cleanup(tmpAudio, tmpVideo, tmpOut)
                    fail(e0)
                } else if (m in Splitter.REMUX_VIDEO) {
                    mux(v, base, tmpAudio, tmpVideo, tmpOut, app)
                } else {
                    // Videoformat lässt sich nicht umpacken (zum Beispiel VP9): erst nach H.264 umwandeln.
                    progressText.text = "Wandle das Video um (dauert länger) …"
                    progressBar.progress = 0
                    Transcoder.run(this, v, tmpVideo, 0L, 0L,
                        onProgress = { pct -> progressBar.progress = pct },
                        onDone = { err2 ->
                            if (err2 != null) {
                                cleanup(tmpAudio, tmpVideo, tmpOut)
                                fail(err2)
                            } else {
                                mux(Uri.fromFile(tmpVideo), base, tmpAudio, tmpVideo, tmpOut, app)
                            }
                        },
                        removeAudio = true
                    )
                }
            }
        }.start()
    }

    private fun mux(videoSrc: Uri, base: String, tmpAudio: File, tmpVideo: File, tmpOut: File, app: android.content.Context, suffix: String = "_neuer_Ton") {
        progressBar.isIndeterminate = true
        progressText.text = "Füge Ton und Video zusammen …"
        Thread {
            var out: Uri? = null
            var err: String? = null
            try {
                Merger.mux(app, videoSrc, Uri.fromFile(tmpAudio), tmpOut)
                out = Splitter.createOutput(app, "$base$suffix.mp4")
                Splitter.copyToGallery(app, tmpOut, out)
                Splitter.finish(app, out)
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
                out?.let { Splitter.discard(app, it) }
                out = null
            }
            cleanup(tmpAudio, tmpVideo, tmpOut)
            val done = out
            val e1 = err
            main.post {
                if (done == null) {
                    fail(e1 ?: "unbekannt")
                } else {
                    setBusy(false)
                    progressBar.visibility = View.GONE
                    progressText.text = "Fertig: $base$suffix.mp4 in Filme/Video-Teiler gespeichert."
                    showResult(done)
                }
            }
        }.start()
    }

    /** Mehrere Videos: erst Bild (und ggf. Originalton) zusammenrechnen, dann optional neuen Ton einsetzen. */
    private fun startConcat() {
        val a = audioUri
        if (mode == 2 && a == null) return
        setBusy(true)
        resultBox.removeAllViews()
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = false
        progressBar.max = 100
        progressBar.progress = 0
        stopPreview()

        val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.GERMANY).format(java.util.Date())
        val base = "Zusammenschnitt_$stamp"
        val tmpAudio = File(cacheDir, "merge.audio.m4a")
        val tmpVideo = File(cacheDir, "merge.video.mp4")
        val tmpOut = File(cacheDir, "merge.out.mp4")
        val app = applicationContext

        // Zielgröße: Hoch- oder Querformat nach dem ersten Video, Qualitätsstufe nach Kurzseite.
        val portrait = isPortrait(clips[0].uri)
        val short = intArrayOf(480, 720, 1080)[quality]
        val long = intArrayOf(854, 1280, 1920)[quality]
        val w = if (portrait) short else long
        val h = if (portrait) long else short
        val bitrate = intArrayOf(1_200_000, 2_500_000, 5_000_000)[quality]

        progressText.text = "Rechne die Videos zusammen (dauert eine Weile) …"
        Transcoder.concat(this, clips.map { it.uri }, tmpVideo, w, h, bitrate, mode != 0,
            onProgress = { pct -> progressBar.progress = pct },
            onDone = { err ->
                if (err != null) {
                    cleanup(tmpAudio, tmpVideo, tmpOut)
                    fail(err)
                } else if (mode == 2 && a != null) {
                    progressBar.progress = 0
                    progressText.text = if (offsetSec > 0) "Schneide den Ton ab ${Ui.fmt(offsetSec.toLong())} zu …" else "Bereite den Ton vor …"
                    Transcoder.run(this, a, tmpAudio, offsetSec * 1000L, 0L,
                        onProgress = { pct -> progressBar.progress = pct },
                        onDone = { err2 ->
                            if (err2 != null) {
                                cleanup(tmpAudio, tmpVideo, tmpOut)
                                fail("$err2 (hat die Datei einen Ton?)")
                            } else {
                                mux(Uri.fromFile(tmpVideo), base, tmpAudio, tmpVideo, tmpOut, app, "")
                            }
                        },
                        removeVideo = true
                    )
                } else {
                    publish(tmpVideo, base, tmpAudio, tmpVideo, tmpOut, app)
                }
            }
        )
    }

    private fun isPortrait(u: Uri): Boolean {
        val r = android.media.MediaMetadataRetriever()
        return try {
            r.setDataSource(this, u)
            val w = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val swap = rot == 90 || rot == 270
            val dw = if (swap) h else w
            val dh = if (swap) w else h
            dh > dw
        } catch (e: Exception) {
            false
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }

    /** Fertiges Video (ohne weiteren Schritt) in die Galerie legen. */
    private fun publish(file: File, base: String, tmpAudio: File, tmpVideo: File, tmpOut: File, app: android.content.Context) {
        progressBar.isIndeterminate = true
        progressText.text = "Speichere das Video …"
        Thread {
            var out: Uri? = null
            var err: String? = null
            try {
                out = Splitter.createOutput(app, "$base.mp4")
                Splitter.copyToGallery(app, file, out)
                Splitter.finish(app, out)
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
                out?.let { Splitter.discard(app, it) }
                out = null
            }
            cleanup(tmpAudio, tmpVideo, tmpOut)
            val done = out
            val e1 = err
            main.post {
                if (done == null) {
                    fail(e1 ?: "unbekannt")
                } else {
                    setBusy(false)
                    progressBar.visibility = View.GONE
                    progressText.text = "Fertig: $base.mp4 in Filme/Video-Teiler gespeichert."
                    showResult(done)
                }
            }
        }.start()
    }

    private fun cleanup(vararg files: File) {
        for (f in files) {
            try {
                f.delete()
            } catch (e: Exception) {
                // egal
            }
        }
    }

    private fun showResult(uri: Uri) {
        resultBox.removeAllViews()
        val play = Ui.button(this, "Ansehen", false) { Player.open(this, uri, "video/mp4") }
        val pick = Player.button(this, uri, "video/mp4")
        val share = Ui.button(this, "Teilen", false) {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Teilen mit"))
        }
        play.textSize = 14f
        share.textSize = 14f
        resultBox.addView(play, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
        resultBox.addView(share, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
        resultBox.addView(pick, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
    }
}
