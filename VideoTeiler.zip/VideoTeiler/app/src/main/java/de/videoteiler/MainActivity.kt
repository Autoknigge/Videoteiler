package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Startbildschirm mit den vier Werkzeugen. */
class MainActivity : Activity() {

    companion object {
        private var introShown = false
    }

    private val PRIVACY_URL = "https://autoknigge.de/videoteiler/datenschutz.html"
    private val IMPRINT_URL = "https://autoknigge.de/impressum"

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(26), dp(12), dp(26), dp(8))
        }

        // Nur das Logo, flach, in einem goldenen 3D-Rahmen mit Farbverlauf.
        val logo = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.logo_voll)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            contentDescription = getString(R.string.app_name)
        }
        val frame = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = Ui.tile3d(
                this@MainActivity, Ui.BG,
                intArrayOf(Color.parseColor("#1F5A40"), Color.parseColor("#123324"), Color.parseColor("#071811"))
            )
            setPadding(dp(22), dp(10), dp(25), dp(16))
        }
        frame.addView(logo, LinearLayout.LayoutParams(Ui.MATCH, dp(64)))
        box.addView(frame, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { bottomMargin = dp(6) })

        tool(box, "✂️", "Video teilen", "In Teile à 30, 60 oder 90 Sek.", Ui.TILE_OCKER, SplitActivity::class.java)
        tool(box, "💾", "Status sichern", "WhatsApp-Status in die Galerie", Ui.TILE_RED, StatusActivity::class.java)
        tool(box, "🎧", "Ton aus Video holen", "Tonspur als m4a speichern", Ui.TILE_BROWN, AudioActivity::class.java)
        tool(box, "🎬", "Ton und Video zusammenführen", "Video mit neuem Ton", Ui.TILE_OLIVE, MergeActivity::class.java)

        // Fuß: Datenschutz und Impressum (öffnen im Browser)
        val foot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        foot.addView(link("Datenschutz", PRIVACY_URL))
        foot.addView(Ui.text(this, "  ·  ", 13f, Ui.MUTED, false))
        foot.addView(link("Impressum", IMPRINT_URL))
        // "Werbe-Einstellungen" nur, wenn Google sie für diesen Nutzer vorschreibt (Einwilligung ändern).
        val adSep = Ui.text(this, "  ·  ", 13f, Ui.MUTED, false).apply { visibility = View.GONE }
        val adLink = actionLink("Werbe-Einstellungen") { Ads.showPrivacyOptions(this) }.apply { visibility = View.GONE }
        foot.addView(adSep)
        foot.addView(adLink)
        Ads.whenPrivacyOptionsRequired(this) {
            adSep.visibility = View.VISIBLE
            adLink.visibility = View.VISIBLE
        }
        box.addView(foot, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(10) })
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { null }
        if (ver != null) {
            box.addView(
                Ui.text(this, "Version $ver", 12f, Ui.MUTED, false).apply { gravity = Gravity.CENTER },
                LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
            )
        }

        val scroll = ScrollView(this)
        scroll.addView(box, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
        // Gratis-Ausgabe: Banner unten (erst nach der Einwilligung). Pro-Ausgabe: macht nichts.
        // Start-Ausgabe: einmal pro App-Start die App-Start-Anzeige im Vollbild; Google steuert Dauer und Schließen-Knopf.
        if (resources.getBoolean(R.bool.intro_ad) && !introShown) {
            introShown = true
            Ads.showStartAd(this)
        }
    }

    private fun link(label: String, url: String): TextView =
        Ui.text(this, label, 13f, Ui.GOLD, false).apply {
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this@MainActivity, "Kein Browser gefunden.", Toast.LENGTH_LONG).show()
                }
            }
        }

    private fun actionLink(label: String, onClick: () -> Unit): TextView =
        Ui.text(this, label, 13f, Ui.GOLD, false).apply {
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { onClick() }
        }

    private fun tool(parent: LinearLayout, icon: String, title: String, desc: String, colors: Ui.TileColors, target: Class<*>) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.tile3d(this@MainActivity, colors.fill)
            setPadding(dp(18), dp(10), dp(21), dp(16))
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, target)) }
        }
        Ui.pressEffect(this, card)
        val ic = Ui.text(this, icon, 24f, colors.title, false)
        ic.gravity = Gravity.CENTER
        card.addView(ic, LinearLayout.LayoutParams(dp(38), Ui.WRAP).apply { rightMargin = dp(8) })

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(Ui.text(this, title, 16f, colors.title, true))
        texts.addView(Ui.text(this, desc, 13f, colors.text, false))
        card.addView(texts, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        card.addView(Ui.text(this, "›", 24f, colors.title, true))
        parent.addView(card, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
    }
}
