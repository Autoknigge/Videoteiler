package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    companion object {
        private const val REQ_PICK = 41
        private val BG = Color.parseColor("#0D1218")
        private val SURFACE = Color.parseColor("#18212B")
        private val INK = Color.parseColor("#E7ECF2")
        private val MUTED = Color.parseColor("#9AA7B6")
        private val ACCENT = Color.parseColor("#00A884")
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private val main = Handler(Looper.getMainLooper())

    private var source: Uri? = null
    private var info: SourceInfo? = null
    private var partSec = 90
    private var busy = false
    private val clips = ArrayList<Clip>()

    private lateinit var infoText: TextView
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var pickBtn: Button
    private lateinit var splitBtn: Button
    private lateinit var chips: List<Button>
    private lateinit var listBox: LinearLayout
    private lateinit var shareBar: LinearLayout
    private lateinit var hint: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    // ------------------------------------------------------------------ Aufbau

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        top.addView(text("Video-Teiler", 26f, INK, true))
        top.addView(text("Schneidet ein langes Video in Teile für den WhatsApp-Status.", 14f, MUTED, false))

        pickBtn = button("Video auswählen", true) { pickVideo() }
        top.addView(pickBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })

        infoText = text("Noch kein Video gewählt.", 15f, INK, false)
        infoText.setPadding(dp(14), dp(12), dp(14), dp(12))
        infoText.background = round(SURFACE, 14)
        top.addView(infoText, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        top.addView(text("Länge pro Teil", 13f, MUTED, true), LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(14) })
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val made = ArrayList<Button>()
        for ((label, sec) in listOf("30 Sek." to 30, "60 Sek." to 60, "90 Sek." to 90)) {
            val b = Button(this).apply {
                isAllCaps = false
                text = label
                textSize = 14f
                setOnClickListener {
                    partSec = sec
                    styleChips()
                    refreshInfo()
                }
            }
            made.add(b)
            chipRow.addView(b, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
        }
        chips = made
        top.addView(chipRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })

        splitBtn = button("In Teile schneiden", true) { startSplit() }
        top.addView(splitBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        progressText = text("", 13f, MUTED, false)
        top.addView(progressText, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(ACCENT)
            visibility = View.GONE
        }
        top.addView(progressBar, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(12))
        }
        val scroll = ScrollView(this)
        scroll.addView(listBox, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        shareBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(12))
            setBackgroundColor(SURFACE)
            visibility = View.GONE
        }
        hint = text("In WhatsApp oben „Mein Status“ wählen und senden.", 13f, MUTED, false)
        shareBar.addView(hint)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val b1 = button("An WhatsApp", true) { share(clips, "com.whatsapp") }
        val b2 = button("An WhatsApp Business", false) { share(clips, "com.whatsapp.w4b") }
        b1.textSize = 14f
        b2.textSize = 14f
        row.addView(b1, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(8) })
        row.addView(b2, LinearLayout.LayoutParams(0, WRAP, 1f))
        shareBar.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        root.addView(shareBar, LinearLayout.LayoutParams(MATCH, WRAP))

        // Ab Android 15/16 zeichnet die App hinter den Systemleisten. Der Hintergrund reicht darunter,
        // der Inhalt bekommt den nötigen Abstand.
        root.setOnApplyWindowInsetsListener { v, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsets.CONSUMED
        }
        setContentView(root)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.insetsController?.setSystemBarsAppearance(
            0,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )

        styleChips()
        refreshInfo()
        handleIncoming(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    /** Video, das aus der Galerie oder einer anderen App an Video-Teiler geteilt wurde. */
    private fun handleIncoming(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_SEND) return
        @Suppress("DEPRECATION")
        val uri = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: return
        setSource(uri)
    }

    // ------------------------------------------------------------------ Auswahl

    private fun pickVideo() {
        // Die Foto-Auswahl von Android zeigt bei Videos die Länge an. Gibt es sie auf diesem
        // Handy nicht, wird die normale Dateiauswahl genommen.
        try {
            val photo = Intent(MediaStore.ACTION_PICK_IMAGES).apply { type = "video/*" }
            @Suppress("DEPRECATION")
            startActivityForResult(photo, REQ_PICK)
            return
        } catch (e: Exception) {
            // weiter mit der Dateiauswahl
        }
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        @Suppress("DEPRECATION")
        startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            setSource(uri)
        }
    }

    private fun setSource(uri: Uri) {
        if (busy) return
        try {
            info = Splitter.readInfo(this, uri)
            source = uri
        } catch (e: Exception) {
            info = null
            source = null
            toast("Dieses Video konnte nicht gelesen werden.")
        }
        clips.clear()
        listBox.removeAllViews()
        shareBar.visibility = View.GONE
        progressText.text = ""
        progressBar.visibility = View.GONE
        refreshInfo()
    }

    private fun refreshInfo() {
        val inf = info
        if (inf == null) {
            infoText.text = "Noch kein Video gewählt."
            splitBtn.isEnabled = false
            return
        }
        val sec = inf.durationUs / 1_000_000L
        val parts = if (sec <= 0) 0 else ((sec + partSec - 1) / partSec).toInt()
        infoText.text = "${inf.name}\nLänge ${fmt(sec)} Min. · ca. $parts Teile à ${fmt(partSec.toLong())}"
        splitBtn.isEnabled = !busy && sec > 0
    }

    // ------------------------------------------------------------------ Schneiden

    private fun startSplit() {
        val uri = source ?: return
        val inf = info ?: return
        if (busy) return
        busy = true
        setControls(false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        clips.clear()
        listBox.removeAllViews()
        shareBar.visibility = View.GONE
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = true
        progressText.text = "Analysiere Video …"

        val base = inf.name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
            .trim('_')
            .take(40)
            .ifEmpty { "Video" }
        val sec = partSec

        Thread {
            var prep: Prep? = null
            var error: String? = null
            try {
                prep = Splitter.prepare(applicationContext, uri)
            } catch (e: Exception) {
                error = e.message ?: e.javaClass.simpleName
            }
            val ready = prep
            val failed = error
            main.post {
                if (ready != null) runFrom(ready, uri, base, sec, 0L, 1, ArrayList()) else finishSplit(emptyList(), failed)
            }
        }.start()
    }

    /** Schneidet Teil [index] ab Zeitpunkt [start] und macht danach mit dem nächsten weiter. */
    private fun runFrom(p: Prep, uri: Uri, base: String, sec: Int, start: Long, index: Int, made: MutableList<Clip>) {
        val dur = p.tracks.durationUs
        if (start >= dur - 100_000L) {
            finishSplit(made, null)
            return
        }
        val partUs = sec * 1_000_000L
        val end = Splitter.nextEnd(p, start, partUs)
        val total = Splitter.estimateParts(p, partUs)
        val name = "%s_Teil%02d.mp4".format(base, index)
        val app = applicationContext
        val seconds = ((end - start) / 1_000_000L).toInt()

        if (!p.transcode) {
            progressBar.isIndeterminate = true
            progressText.text = "Schneide Teil $index von ca. $total …"
            Thread {
                var err: String? = null
                var dst: Uri? = null
                try {
                    dst = Splitter.createOutput(app, name)
                    Splitter.remuxSegment(app, uri, dst, p, start, end)
                    Splitter.finish(app, dst)
                } catch (e: Exception) {
                    err = e.message ?: e.javaClass.simpleName
                    dst?.let { Splitter.discard(app, it) }
                    dst = null
                }
                val outUri = dst
                val outErr = err
                main.post {
                    if (outErr == null && outUri != null) {
                        made.add(Clip(outUri, name, seconds))
                        runFrom(p, uri, base, sec, end, index + 1, made)
                    } else {
                        // Umpacken geht nicht: stattdessen nach H.264 umwandeln.
                        p.transcode = true
                        runFrom(p, uri, base, sec, start, index, made)
                    }
                }
            }.start()
        } else {
            progressBar.isIndeterminate = false
            progressBar.max = 100
            progressBar.progress = 0
            progressText.text = "Wandle Teil $index von ca. $total um (dauert etwas länger) …"
            val tmp = File(cacheDir, "umwandeln.mp4")
            Transcoder.run(this, uri, tmp, start / 1000L, end / 1000L,
                onProgress = { pct -> progressBar.progress = pct },
                onDone = { terr ->
                    if (terr != null) {
                        tmp.delete()
                        finishSplit(made, terr)
                    } else {
                        Thread {
                            var err: String? = null
                            var dst: Uri? = null
                            try {
                                dst = Splitter.createOutput(app, name)
                                Splitter.copyToGallery(app, tmp, dst)
                                Splitter.finish(app, dst)
                            } catch (e: Exception) {
                                err = e.message ?: e.javaClass.simpleName
                                dst?.let { Splitter.discard(app, it) }
                                dst = null
                            }
                            tmp.delete()
                            val outUri = dst
                            val outErr = err
                            main.post {
                                if (outErr == null && outUri != null) {
                                    made.add(Clip(outUri, name, seconds))
                                    runFrom(p, uri, base, sec, end, index + 1, made)
                                } else {
                                    finishSplit(made, outErr)
                                }
                            }
                        }.start()
                    }
                })
        }
    }

    private fun finishSplit(made: List<Clip>, error: String?) {
        busy = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setControls(true)
        clips.clear()
        clips.addAll(made)
        progressBar.visibility = View.GONE
        progressText.text = when {
            error != null && made.isEmpty() -> "Fehler: $error"
            error != null -> "${made.size} Teile fertig, dann Fehler: $error"
            else -> "Fertig: ${made.size} Teile in Filme/Video-Teiler gespeichert."
        }
        showClips()
        refreshInfo()
    }

    private fun setControls(on: Boolean) {
        pickBtn.isEnabled = on
        splitBtn.isEnabled = on
        for (c in chips) c.isEnabled = on
    }

    // ------------------------------------------------------------------ Ergebnis

    private fun showClips() {
        listBox.removeAllViews()
        for ((i, c) in clips.withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(8), dp(8), dp(8))
                background = round(SURFACE, 14)
            }
            row.addView(
                text("Teil ${i + 1} · ${fmt(c.seconds.toLong())}", 16f, INK, true),
                LinearLayout.LayoutParams(0, WRAP, 1f)
            )
            val view = smallButton("Ansehen") { play(c) }
            val shr = smallButton("Teilen") { share(listOf(c), null) }
            row.addView(view)
            row.addView(shr)
            listBox.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        }
        shareBar.visibility = if (clips.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun play(c: Clip) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(c.uri, "video/mp4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            toast("Keine App zum Abspielen gefunden.")
        }
    }

    private fun share(list: List<Clip>, pkg: String?) {
        if (list.isEmpty()) return
        val i = if (list.size == 1) {
            Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, list[0].uri) }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(list.map { it.uri }))
            }
        }
        i.type = "video/mp4"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            if (pkg != null) {
                i.setPackage(pkg)
                startActivity(i)
            } else {
                startActivity(Intent.createChooser(i, "Teilen mit"))
            }
        } catch (e: ActivityNotFoundException) {
            toast(if (pkg == "com.whatsapp.w4b") "WhatsApp Business ist nicht installiert." else "WhatsApp ist nicht installiert.")
        }
    }

    // ------------------------------------------------------------------ Hilfen

    private fun fmt(sec: Long): String = "%d:%02d".format(sec / 60, sec % 60)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun round(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun text(s: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 16f
            setTextColor(if (primary) Color.WHITE else INK)
            background = round(if (primary) ACCENT else SURFACE, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnClickListener { onClick() }
        }

    private fun smallButton(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            setTextColor(ACCENT)
            background = null
            setPadding(dp(10), dp(6), dp(10), dp(6))
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { onClick() }
        }

    private fun styleChips() {
        val sel = when (partSec) {
            30 -> 0
            60 -> 1
            else -> 2
        }
        for ((i, b) in chips.withIndex()) {
            val on = i == sel
            b.setTextColor(if (on) Color.WHITE else INK)
            b.background = round(if (on) ACCENT else SURFACE, 12)
        }
    }
}
