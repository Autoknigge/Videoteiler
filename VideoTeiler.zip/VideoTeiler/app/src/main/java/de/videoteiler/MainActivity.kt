package de.videoteiler

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView

/** Startbildschirm mit den vier Werkzeugen. */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 24))
        }
        box.addView(Ui.text(this, "Video-Teiler", 28f, Ui.INK, true))
        box.addView(Ui.text(this, "Kleine Werkzeuge für Videos und den WhatsApp-Status.", 14f, Ui.MUTED, false))

        tool(box, "Video teilen", "Langes Video in Teile à 30, 60 oder 90 Sekunden schneiden und in den WhatsApp-Status schicken.", SplitActivity::class.java)
        tool(box, "Status sichern", "Angesehene Status von WhatsApp und WhatsApp Business finden und in der Galerie speichern.", StatusActivity::class.java)
        tool(box, "Ton aus Video holen", "Die Tonspur eines Videos als Audiodatei (m4a) speichern.", AudioActivity::class.java)
        tool(box, "Ton und Video zusammenführen", "Ein Video mit einer Audiodatei vertonen. Der Originalton wird ersetzt.", MergeActivity::class.java)

        val scroll = ScrollView(this)
        scroll.addView(box, android.view.ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        setContentView(root)
        Ui.bars(this)
    }

    private fun tool(parent: LinearLayout, title: String, desc: String, target: Class<*>) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(this@MainActivity, Ui.SURFACE, 16)
            setPadding(Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 14))
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, target)) }
        }
        card.addView(Ui.text(this, title, 18f, Ui.ACCENT, true))
        card.addView(Ui.text(this, desc, 14f, Ui.INK, false))
        parent.addView(card, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = Ui.dp(this@MainActivity, 14) })
    }
}
