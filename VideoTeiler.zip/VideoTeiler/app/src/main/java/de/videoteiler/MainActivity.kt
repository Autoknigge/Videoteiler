package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Startbildschirm mit den vier Werkzeugen. */
class MainActivity : Activity() {

    private val PRIVACY_URL = "https://autoknigge.de/videoteiler/datenschutz.html"
    private val IMPRINT_URL = "https://autoknigge.de/impressum"

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }

        // Nur das Logo, flach, in einem goldenen 3D-Rahmen mit Farbverlauf.
        val logo = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.logo_voll)
            adjustViewBounds = true
            contentDescription = getString(R.string.app_name)
        }
        val frame = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = Ui.tile3d(
                this@MainActivity, Ui.BG,
                intArrayOf(Color.parseColor("#14724A"), Color.parseColor("#0B4A2F"), Color.parseColor("#052B1B"))
            )
            setPadding(dp(22), dp(16), dp(25), dp(22))
        }
        frame.addView(logo, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        box.addView(frame, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { bottomMargin = dp(6) })

        tool(box, "✂️", "Video teilen", "Langes Video in Teile à 30, 60 oder 90 Sekunden schneiden und in den WhatsApp-Status schicken.", Ui.TILE_OCKER, SplitActivity::class.java)
        tool(box, "💾", "Status sichern", "Angesehene Status von WhatsApp und WhatsApp Business finden und in der Galerie speichern.", Ui.TILE_RED, StatusActivity::class.java)
        tool(box, "🎧", "Ton aus Video holen", "Die Tonspur eines Videos als Audiodatei (m4a) speichern.", Ui.TILE_BROWN, AudioActivity::class.java)
        tool(box, "🎬", "Ton und Video zusammenführen", "Ein Video mit einer Audiodatei vertonen. Der Originalton wird ersetzt.", Ui.TILE_OLIVE, MergeActivity::class.java)

        // Fuß: Datenschutz und Impressum (öffnen im Browser)
        val foot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        foot.addView(link("Datenschutz", PRIVACY_URL))
        foot.addView(Ui.text(this, "  ·  ", 13f, Ui.MUTED, false))
        foot.addView(link("Impressum", IMPRINT_URL))
        if (Ads.enabled) {
            foot.addView(Ui.text(this, "  ·  ", 13f, Ui.MUTED, false))
            foot.addView(actionLink("Werbe-Einstellungen") { Ads.showPrivacyOptions(this) })
        }
        box.addView(foot, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(28) })

        val scroll = ScrollView(this)
        scroll.addView(box, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        Ui.bars(this)
        // Gratis-Ausgabe: Banner unten (erst nach der Einwilligung). Pro-Ausgabe: macht nichts.
        Ads.attach(this, root)
    }

    private fun link(label: String, url: String): TextView =
        Ui.text(this, label, 13f, Ui.GOLD, false).apply {
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this@MainActivity, "Kein Browser gefunden.", Toast.LENGTH_LONG).show()
                }
            }
        }

    private fun actionLink(label: String, onClick: () -> Unit): TextView =
        Ui.text(this, label, 13f, Ui.GOLD, false).apply {
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { onClick() }
        }

    private fun tool(parent: LinearLayout, icon: String, title: String, desc: String, colors: Ui.TileColors, target: Class<*>) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.tile3d(this@MainActivity, colors.fill)
            setPadding(dp(19), dp(17), dp(22), dp(23))
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, target)) }
        }
        Ui.pressEffect(this, card)
        val ic = Ui.text(this, icon, 30f, colors.title, false)
        ic.gravity = Gravity.CENTER
        card.addView(ic, LinearLayout.LayoutParams(dp(48), Ui.WRAP).apply { rightMargin = dp(12) })

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(Ui.text(this, title, 19f, colors.title, true))
        texts.addView(Ui.text(this, desc, 14f, colors.text, false))
        card.addView(texts, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        card.addView(Ui.text(this, "›", 28f, colors.title, true))
        parent.addView(card, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })
    }
}
