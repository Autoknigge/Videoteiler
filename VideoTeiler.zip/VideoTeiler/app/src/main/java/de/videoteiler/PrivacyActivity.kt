package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Speichert eine Kopie des Videos ohne Standort- und Gerätedaten (verlustfrei, ohne Neuberechnung). */
class PrivacyActivity : Activity() {

    private val REQ = 71
    private val main = Handler(Looper.getMainLooper())
    private var src: Uri? = null
    private var info: SourceInfo? = null
    private var busy = false

    private lateinit var infoText: TextView
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var pickBtn: Button
    private lateinit var goBtn: Button
    private lateinit var resultBox: LinearLayout

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        top.addView(
            Ui.header(this, "Privatsphäre-Kopie", "Entfernt Standort und Gerätedaten, bevor du ein Video verschickst.", Ui.TILE_PINE),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        )

        pickBtn = Ui.button(this, "Video auswählen", true) { Ui.pickVideo(this, REQ) }
        top.addView(pickBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        infoText = Ui.text(this, "Noch kein Video gewählt.", 15f, Ui.INK, false)
        Ui.panel(this, infoText)
        top.addView(infoText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })

        top.addView(
            Ui.text(
                this,
                "Bild und Ton bleiben unverändert, es geht also nichts an Qualität verloren. Die Kopie hat keine Standortangabe und keinen Gerätenamen mehr. Das Original bleibt erhalten.",
                13f, Ui.MUTED, false
            ),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(10) }
        )

        goBtn = Ui.button(this, "Kopie ohne Daten speichern", true) { start() }
        goBtn.isEnabled = false
        top.addView(goBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })

        progressText = Ui.text(this, "", 13f, Ui.MUTED, false)
        top.addView(progressText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            visibility = View.GONE
        }
        top.addView(progressBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        resultBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(resultBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val inf = Splitter.readInfo(this, uri)
                info = inf
                src = uri
                val loc = if (Cleaner.hasLocation(this, uri)) "enthält einen Standort" else "enthält keinen Standort"
                infoText.text = "${inf.name}\nLänge ${Ui.fmt(inf.durationUs / 1_000_000L)} Min. · $loc"
                goBtn.isEnabled = true
            } catch (e: Exception) {
                src = null
                info = null
                goBtn.isEnabled = false
                infoText.text = "Dieses Video konnte nicht gelesen werden."
            }
            resultBox.removeAllViews()
            progressText.text = ""
        }
    }

    private fun start() {
        val uri = src ?: return
        val inf = info ?: return
        if (busy) return
        busy = true
        pickBtn.isEnabled = false
        goBtn.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        resultBox.removeAllViews()
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = true
        progressText.text = "Erstelle die Kopie …"

        val base = inf.name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
            .trim('_')
            .take(40)
            .ifEmpty { "Video" }
        val tmp = File(cacheDir, "privat.tmp.mp4")
        val app = applicationContext
        Thread {
            var out: Uri? = null
            var err: String? = null
            var stillLoc = false
            try {
                Cleaner.clean(app, uri, tmp)
                stillLoc = Cleaner.hasLocation(tmp)
                out = Splitter.createOutput(app, "${base}_privat.mp4")
                Splitter.copyToGallery(app, tmp, out)
                Splitter.finish(app, out)
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
                out?.let { Splitter.discard(app, it) }
                out = null
            }
            try { tmp.delete() } catch (e: Exception) { }
            val done = out
            val e1 = err
            val loc = stillLoc
            main.post {
                busy = false
                pickBtn.isEnabled = true
                goBtn.isEnabled = true
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                progressBar.visibility = View.GONE
                if (done == null) {
                    progressText.text = "Fehler: ${e1 ?: "unbekannt"}"
                } else {
                    progressText.text =
                        if (loc) "Gespeichert als ${base}_privat.mp4 in Filme/Video-Teiler. Achtung: Es ist noch eine Standortangabe enthalten."
                        else "Fertig: ${base}_privat.mp4 in Filme/Video-Teiler gespeichert. Kein Standort mehr enthalten."
                    showResult(done)
                }
            }
        }.start()
    }

    private fun showResult(uri: Uri) {
        resultBox.removeAllViews()
        val play = Ui.button(this, "Ansehen", false) {
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startActivity(i)
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this, "Keine App zum Abspielen gefunden.", Toast.LENGTH_LONG).show()
            }
        }
        val share = Ui.button(this, "Teilen", false) {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(i, "Teilen mit"))
        }
        play.textSize = 14f
        share.textSize = 14f
        resultBox.addView(play, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
        resultBox.addView(share, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
    }
}
