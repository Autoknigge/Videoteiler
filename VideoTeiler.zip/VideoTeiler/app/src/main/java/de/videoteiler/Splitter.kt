package de.videoteiler

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.nio.ByteBuffer

/** Ein fertiges Teilstück in der Galerie. */
class Clip(val uri: Uri, val name: String, val seconds: Int)

/** Das gewählte Video: Name und Länge. */
class SourceInfo(val name: String, val durationUs: Long)

/**
 * Schneidet ein Video ohne Neuberechnung in Teile (nur Umpacken). Dadurch geht es schnell und die
 * Bildqualität bleibt unverändert. Geschnitten wird an Schlüsselbildern, deshalb sind die Teile
 * meist ein paar Sekunden kürzer als die Wunschlänge, aber nie länger.
 */
object Splitter {

    fun readInfo(ctx: Context, uri: Uri): SourceInfo {
        var name = "Video"
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: name
            }
        } catch (e: Exception) {
            // Name bleibt "Video"
        }
        val r = MediaMetadataRetriever()
        var dur = 0L
        try {
            r.setDataSource(ctx, uri)
            dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
        } finally {
            r.release()
        }
        return SourceInfo(name, dur)
    }

    private class Tracks(val video: Int, val audio: Int, val durationUs: Long, val rotation: Int)

    private fun readTracks(ctx: Context, uri: Uri): Tracks {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            var video = -1
            var audio = -1
            var dur = 0L
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && video < 0) {
                    video = i
                    if (f.containsKey(MediaFormat.KEY_DURATION)) dur = f.getLong(MediaFormat.KEY_DURATION)
                } else if (mime.startsWith("audio/") && audio < 0) {
                    audio = i
                }
            }
            if (video < 0) throw IllegalStateException("Keine Videospur gefunden.")
            val r = MediaMetadataRetriever()
            var rot = 0
            try {
                r.setDataSource(ctx, uri)
                rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (dur <= 0L) {
                    dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
                }
            } finally {
                r.release()
            }
            return Tracks(video, audio, dur, rot)
        } finally {
            ex.release()
        }
    }

    /** Zeitpunkte (in Mikrosekunden) aller Schlüsselbilder der Videospur, sortiert. */
    private fun syncTimes(ctx: Context, uri: Uri, videoIndex: Int): LongArray {
        val ex = MediaExtractor()
        val out = ArrayList<Long>()
        try {
            ex.setDataSource(ctx, uri, null)
            ex.selectTrack(videoIndex)
            while (true) {
                val t = ex.sampleTime
                if (t < 0) break
                if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) out.add(t)
                if (!ex.advance()) break
            }
        } finally {
            ex.release()
        }
        out.sort()
        return out.toLongArray()
    }

    /** Berechnet die Schnittstellen: je Teil [Start, Ende) in Mikrosekunden. */
    private fun plan(sync: LongArray, durationUs: Long, partUs: Long): List<LongArray> {
        val cuts = ArrayList<LongArray>()
        var start = 0L
        while (start < durationUs - 100_000L) {
            val target = start + partUs
            if (target >= durationUs) {
                cuts.add(longArrayOf(start, durationUs))
                break
            }
            var end = -1L
            for (s in sync) {
                if (s > start && s <= target) end = s
            }
            if (end < 0L) {
                // Kein Schlüsselbild im Zeitfenster: nächstes nehmen, dieser Teil wird etwas länger.
                end = sync.firstOrNull { it > target } ?: durationUs
            }
            cuts.add(longArrayOf(start, end))
            start = end
        }
        return cuts
    }

    private fun createOutput(ctx: Context, name: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Video-Teiler")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        return ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Die Datei konnte nicht angelegt werden.")
    }

    private fun writeSegment(
        ctx: Context, src: Uri, dst: Uri, t: Tracks, startUs: Long, endUs: Long
    ) {
        val ex = MediaExtractor()
        // Zuerst in eine Zwischendatei schreiben (zuverlässigster Weg für den Muxer),
        // danach in die Galerie kopieren.
        val tmp = java.io.File(ctx.cacheDir, "teil.tmp.mp4")
        if (tmp.exists()) tmp.delete()
        var mux: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(ctx, src, null)
            val m = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            val map = HashMap<Int, Int>()
            var maxSize = 1 shl 20

            var lastError = ""

            fun add(index: Int): Boolean {
                val f = ex.getTrackFormat(index)
                return try {
                    map[index] = m.addTrack(f)
                    ex.selectTrack(index)
                    if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        maxSize = maxOf(maxSize, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
                    }
                    true
                } catch (e: Exception) {
                    lastError = "${e.javaClass.simpleName}: ${e.message}"
                    false
                }
            }

            if (!add(t.video)) {
                val mime = ex.getTrackFormat(t.video).getString(MediaFormat.KEY_MIME)
                throw IllegalStateException("Videoformat $mime nicht unterstützt ($lastError)")
            }
            val hasAudio = t.audio >= 0 && add(t.audio)

            m.setOrientationHint(t.rotation)
            m.start()
            started = true
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val buf = ByteBuffer.allocateDirect(maxSize + 1024)
            val info = MediaCodec.BufferInfo()
            var videoDone = false
            var audioDone = !hasAudio
            var written = 0

            while (!(videoDone && audioDone)) {
                val time = ex.sampleTime
                if (time < 0L) break
                if (time > endUs + 4_000_000L) break
                val track = ex.sampleTrackIndex
                val isVideo = track == t.video
                val isSync = (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0

                var write = false
                if (isVideo) {
                    if (!videoDone) {
                        if (time >= endUs && isSync) videoDone = true else write = true
                    }
                } else {
                    if (!audioDone) {
                        if (time >= endUs) audioDone = true else if (time >= startUs) write = true
                    }
                }

                if (write) {
                    buf.clear()
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) break
                    info.set(
                        0, size, maxOf(0L, time - startUs),
                        if (isSync) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    )
                    m.writeSampleData(map[track]!!, buf, info)
                    written++
                }
                if (!ex.advance()) break
            }
            if (written == 0) throw IllegalStateException("Leeres Teilstück.")
            try {
                if (started) m.stop()
            } finally {
                started = false
            }
            ctx.contentResolver.openOutputStream(dst, "w")?.use { o ->
                tmp.inputStream().use { it.copyTo(o, 256 * 1024) }
            } ?: throw IllegalStateException("Die Datei konnte nicht geschrieben werden.")
        } finally {
            try {
                if (started) mux?.stop()
            } catch (e: Exception) {
                // egal
            }
            try {
                mux?.release()
            } catch (e: Exception) {
                // egal
            }
            ex.release()
            tmp.delete()
        }
    }

    /**
     * Schneidet das Video in Teile von höchstens [partSec] Sekunden. Fertige Teile landen in [out]
     * (auch dann, wenn später ein Fehler auftritt). [progress] meldet "Teil i von n".
     */
    fun split(
        ctx: Context,
        uri: Uri,
        baseName: String,
        partSec: Int,
        out: MutableList<Clip>,
        progress: (Int, Int) -> Unit
    ) {
        val t = readTracks(ctx, uri)
        val sync = syncTimes(ctx, uri, t.video)
        val cuts = plan(sync, t.durationUs, partSec * 1_000_000L)
        val total = cuts.size
        for ((i, c) in cuts.withIndex()) {
            progress(i + 1, total)
            val name = "%s_Teil%02d.mp4".format(baseName, i + 1)
            val dst = createOutput(ctx, name)
            try {
                writeSegment(ctx, uri, dst, t, c[0], c[1])
                val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                ctx.contentResolver.update(dst, done, null, null)
                out.add(Clip(dst, name, ((c[1] - c[0]) / 1_000_000L).toInt()))
            } catch (e: Exception) {
                try {
                    ctx.contentResolver.delete(dst, null, null)
                } catch (e2: Exception) {
                    // egal
                }
                throw e
            }
        }
    }
}
