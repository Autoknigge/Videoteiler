package de.videoteiler

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.File
import java.nio.ByteBuffer

/** Ein fertiges Teilstück in der Galerie. */
class Clip(val uri: Uri, val name: String, val seconds: Int)

/** Das gewählte Video: Name und Länge. */
class SourceInfo(val name: String, val durationUs: Long)

/** Spuren des Videos. */
class Tracks(
    val video: Int,
    val audio: Int,
    val durationUs: Long,
    val rotation: Int,
    val videoMime: String,
    val audioMime: String?
)

/**
 * Vorbereitung: Spuren, Schlüsselbilder und die Entscheidung, ob das Video verlustfrei umgepackt
 * werden kann ([transcode] = false) oder nach H.264 umgewandelt werden muss.
 */
class Prep(val tracks: Tracks, val sync: LongArray, var transcode: Boolean)

/**
 * Teilt ein Video in Stücke. Kann das Video verlustfrei umgepackt werden (H.264/H.265 mit AAC),
 * geht es schnell und ohne Qualitätsverlust; geschnitten wird dann an Schlüsselbildern und die Teile
 * sind etwas kürzer als gewünscht. Sonst (zum Beispiel bei VP9) wird nach H.264 umgewandelt.
 */
object Splitter {

    private val REMUX_VIDEO = setOf("video/avc", "video/hevc", "video/mp4v-es", "video/3gpp")
    private val REMUX_AUDIO = setOf("audio/mp4a-latm", "audio/3gpp", "audio/amr-wb")

    fun readInfo(ctx: Context, uri: Uri): SourceInfo {
        var name = "Video"
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: name
            }
        } catch (e: Exception) {
            // Name bleibt "Video"
        }
        val r = MediaMetadataRetriever()
        var dur = 0L
        try {
            r.setDataSource(ctx, uri)
            dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
        } finally {
            r.release()
        }
        return SourceInfo(name, dur)
    }

    private fun readTracks(ctx: Context, uri: Uri): Tracks {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            var video = -1
            var audio = -1
            var dur = 0L
            var vMime = ""
            var aMime: String? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && video < 0) {
                    video = i
                    vMime = mime
                    if (f.containsKey(MediaFormat.KEY_DURATION)) dur = f.getLong(MediaFormat.KEY_DURATION)
                } else if (mime.startsWith("audio/") && audio < 0) {
                    audio = i
                    aMime = mime
                }
            }
            if (video < 0) throw IllegalStateException("Keine Videospur gefunden.")
            val r = MediaMetadataRetriever()
            var rot = 0
            try {
                r.setDataSource(ctx, uri)
                rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (dur <= 0L) {
                    dur = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
                }
            } finally {
                r.release()
            }
            return Tracks(video, audio, dur, rot, vMime, aMime)
        } finally {
            ex.release()
        }
    }

    /** Zeitpunkte (in Mikrosekunden) aller Schlüsselbilder der Videospur, sortiert. */
    private fun syncTimes(ctx: Context, uri: Uri, videoIndex: Int): LongArray {
        val ex = MediaExtractor()
        val out = ArrayList<Long>()
        try {
            ex.setDataSource(ctx, uri, null)
            ex.selectTrack(videoIndex)
            while (true) {
                val t = ex.sampleTime
                if (t < 0) break
                if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) out.add(t)
                if (!ex.advance()) break
            }
        } finally {
            ex.release()
        }
        out.sort()
        return out.toLongArray()
    }

    fun prepare(ctx: Context, uri: Uri): Prep {
        val t = readTracks(ctx, uri)
        val canRemux = t.videoMime in REMUX_VIDEO && (t.audioMime == null || t.audioMime in REMUX_AUDIO)
        val sync = if (canRemux) syncTimes(ctx, uri, t.video) else LongArray(0)
        return Prep(t, sync, !canRemux)
    }

    fun estimateParts(p: Prep, partUs: Long): Int =
        if (p.tracks.durationUs <= 0L) 0 else ((p.tracks.durationUs + partUs - 1) / partUs).toInt()

    /** Ende des Teils, das bei [start] beginnt (Mikrosekunden). */
    fun nextEnd(p: Prep, start: Long, partUs: Long): Long {
        val dur = p.tracks.durationUs
        val target = start + partUs
        if (target >= dur) return dur
        if (p.transcode) return target
        var end = -1L
        for (s in p.sync) {
            if (s > start && s <= target) end = s
        }
        if (end < 0L) {
            // Kein Schlüsselbild im Zeitfenster: nächstes nehmen, dieser Teil wird etwas länger.
            end = p.sync.firstOrNull { it > target } ?: dur
        }
        return end
    }

    // ------------------------------------------------------------------ Ausgabe in die Galerie

    fun createOutput(ctx: Context, name: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Video-Teiler")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        return ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Die Datei konnte nicht angelegt werden.")
    }

    fun finish(ctx: Context, uri: Uri) {
        val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
        ctx.contentResolver.update(uri, done, null, null)
    }

    fun discard(ctx: Context, uri: Uri) {
        try {
            ctx.contentResolver.delete(uri, null, null)
        } catch (e: Exception) {
            // egal
        }
    }

    fun copyToGallery(ctx: Context, file: File, dst: Uri) {
        ctx.contentResolver.openOutputStream(dst, "w")?.use { o ->
            file.inputStream().use { it.copyTo(o, 256 * 1024) }
        } ?: throw IllegalStateException("Die Datei konnte nicht geschrieben werden.")
    }

    // ------------------------------------------------------------------ Verlustfrei umpacken

    /** Packt den Abschnitt [startUs, endUs) ohne Neuberechnung um und legt ihn in [dst] ab. */
    fun remuxSegment(ctx: Context, src: Uri, dst: Uri, p: Prep, startUs: Long, endUs: Long) {
        val t = p.tracks
        val ex = MediaExtractor()
        // Zuerst in eine Zwischendatei schreiben (zuverlässigster Weg für den Muxer),
        // danach in die Galerie kopieren.
        val tmp = File(ctx.cacheDir, "teil.tmp.mp4")
        if (tmp.exists()) tmp.delete()
        var mux: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(ctx, src, null)
            val m = MediaMuxer(tmp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux = m
            val map = HashMap<Int, Int>()
            var maxSize = 1 shl 20
            var lastError = ""

            fun add(index: Int): Boolean {
                val f = ex.getTrackFormat(index)
                return try {
                    map[index] = m.addTrack(f)
                    ex.selectTrack(index)
                    if (f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        maxSize = maxOf(maxSize, f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
                    }
                    true
                } catch (e: Exception) {
                    lastError = "${e.javaClass.simpleName}: ${e.message}"
                    false
                }
            }

            if (!add(t.video)) {
                throw IllegalStateException("Videoformat ${t.videoMime} nicht umpackbar ($lastError)")
            }
            val hasAudio = t.audio >= 0 && add(t.audio)

            m.setOrientationHint(t.rotation)
            m.start()
            started = true
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val buf = ByteBuffer.allocateDirect(maxSize + 1024)
            val info = MediaCodec.BufferInfo()
            var videoDone = false
            var audioDone = !hasAudio
            var written = 0

            while (!(videoDone && audioDone)) {
                val time = ex.sampleTime
                if (time < 0L) break
                if (time > endUs + 4_000_000L) break
                val track = ex.sampleTrackIndex
                val isVideo = track == t.video
                val isSync = (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0

                var write = false
                if (isVideo) {
                    if (!videoDone) {
                        if (time >= endUs && isSync) videoDone = true else write = true
                    }
                } else {
                    if (!audioDone) {
                        if (time >= endUs) audioDone = true else if (time >= startUs) write = true
                    }
                }

                if (write) {
                    buf.clear()
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) break
                    info.set(
                        0, size, maxOf(0L, time - startUs),
                        if (isSync) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    )
                    m.writeSampleData(map[track]!!, buf, info)
                    written++
                }
                if (!ex.advance()) break
            }
            if (written == 0) throw IllegalStateException("Leeres Teilstück.")
            try {
                m.stop()
            } finally {
                started = false
            }
            copyToGallery(ctx, tmp, dst)
        } finally {
            try {
                if (started) mux?.stop()
            } catch (e: Exception) {
                // egal
            }
            try {
                mux?.release()
            } catch (e: Exception) {
                // egal
            }
            ex.release()
            tmp.delete()
        }
    }
}
