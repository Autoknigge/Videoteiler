package de.videoteiler

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

/** Die Ordner, in denen die App speichert, und der Zugriff auf die Dateien darin. */
object Store {
    class Cat(val icon: String, val title: String, val path: String, val kind: Int)
    class Item(val name: String, val uri: Uri, val size: Long)

    val cats = listOf(
        Cat("🎞️", "Video", "Movies/Video-Teiler", 0),
        Cat("🎧", "Audio", "Music/Video-Teiler", 1),
        Cat("📸", "Foto (Status)", "Pictures/Status-Sicherer", 2),
        Cat("📹", "Video (Status)", "Movies/Status-Sicherer", 0)
    )

    fun collection(kind: Int): Uri = when (kind) {
        0 -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        1 -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        else -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    }

    fun mime(kind: Int) = when (kind) { 0 -> "video/*"; 1 -> "audio/*"; else -> "image/*" }

    /** Dateien dieser Kategorie, neueste zuerst. */
    fun items(ctx: Context, c: Cat): List<Item> {
        val out = ArrayList<Item>()
        ctx.contentResolver.query(
            collection(c.kind),
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE),
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
            arrayOf(c.path + "/%"),
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { cur ->
            while (cur.moveToNext() && out.size < 500) {
                out.add(Item(cur.getString(1) ?: "Datei", ContentUris.withAppendedId(collection(c.kind), cur.getLong(0)), cur.getLong(2)))
            }
        }
        return out
    }

    fun sizeText(bytes: Long): String =
        if (bytes >= 1_000_000) "%.1f MB".format(bytes / 1_000_000.0) else "%d KB".format(maxOf(1L, bytes / 1000))
}
