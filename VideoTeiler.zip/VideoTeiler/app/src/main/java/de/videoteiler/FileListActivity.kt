package de.videoteiler

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.util.Size
import android.widget.ImageView
import java.util.concurrent.Executors
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.Gravity
import android.content.res.ColorStateList
import android.content.ContentValues
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Dateien eines Ordners: öffnen und einzeln löschen. */
class FileListActivity : Activity() {

    private val REQ_DELETE = 71
    private val REQ_RENAME = 72
    private var pendingUri: Uri? = null
    private var pendingName: String? = null
    private lateinit var cat: Store.Cat
    private lateinit var listBox: LinearLayout
    private lateinit var empty: TextView
    private lateinit var allBtn: android.widget.Button
    private lateinit var delBtn: android.widget.Button
    private val selected = HashSet<Uri>()
    private val pool = Executors.newFixedThreadPool(3)
    private val thumbs = android.util.LruCache<Uri, Bitmap>(80)
    private var shown: List<Store.Item> = emptyList()

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cat = Store.cats[intent.getIntExtra("cat", 0).coerceIn(0, Store.cats.size - 1)]
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        top.addView(
            Ui.header(this, cat.title, cat.path, Ui.TILE_MOSS),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        )
        val folderBtn = Ui.button(this, "Ordner in der Dateien-App öffnen", false) { openFolder() }
        folderBtn.textSize = 14f
        top.addView(folderBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })
        val selRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        allBtn = Ui.button(this, "Alle auswählen", false) { toggleAll() }
        delBtn = Ui.button(this, "Löschen", true) { confirmDelete() }
        allBtn.textSize = 14f
        delBtn.textSize = 14f
        selRow.addView(allBtn, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
        selRow.addView(delBtn, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        top.addView(selRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(10) })
        empty = Ui.text(this, "Hier ist noch nichts gespeichert.", 15f, Ui.MUTED, false)
        empty.setPadding(dp(4), dp(12), dp(4), 0)
        top.addView(empty)
        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(12))
        }
        val scroll = ScrollView(this)
        scroll.addView(listBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        listBox.removeAllViews()
        val list = try { Store.items(this, cat) } catch (e: Exception) { emptyList() }
        shown = list
        selected.retainAll(list.map { it.uri }.toSet())
        empty.visibility = if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        for (item in list) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            Ui.panel(this, row)
            row.setPadding(dp(12), dp(9), dp(14), dp(15))
            val box = CheckBox(this).apply {
                buttonTintList = ColorStateList.valueOf(Ui.GOLD)
                isChecked = item.uri in selected
                setOnCheckedChangeListener { _, on ->
                    if (on) selected.add(item.uri) else selected.remove(item.uri)
                    updateButtons()
                }
            }
            row.addView(box, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { rightMargin = dp(4) })
            val thumb = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(android.graphics.Color.parseColor("#33000000"))
                tag = item.uri
            }
            row.addView(thumb, LinearLayout.LayoutParams(dp(54), dp(54)).apply { rightMargin = dp(10) })
            loadThumb(thumb, item.uri)
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                isClickable = true
                setOnClickListener { open(item) }
            }
            texts.addView(Ui.text(this, item.name, 15f, Ui.INK, true).apply { maxLines = 2 })
            texts.addView(Ui.text(this, Store.sizeText(item.size) + " · antippen zum Öffnen", 12f, Ui.MUTED, false))
            row.addView(texts, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            val ren = Ui.button(this, "✎", false) { askRename(item) }.apply {
                textSize = 16f
                minWidth = 0
                minimumWidth = 0
                setPadding(dp(11), dp(6), dp(14), dp(12))
            }
            row.addView(ren, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { leftMargin = dp(6) })
            listBox.addView(row, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        }
        updateButtons()
    }

    /** Vorschaubild im Hintergrund laden (Töne haben keines). */
    private fun loadThumb(view: ImageView, uri: Uri) {
        val cached = thumbs.get(uri)
        if (cached != null) {
            view.setImageBitmap(cached)
            return
        }
        if (cat.kind == 1) return
        pool.execute {
            try {
                val bm = contentResolver.loadThumbnail(uri, Size(160, 160), null)
                thumbs.put(uri, bm)
                runOnUiThread { if (view.tag == uri) view.setImageBitmap(bm) }
            } catch (e: Exception) {
                // kein Vorschaubild
            }
        }
    }

    override fun onDestroy() {
        pool.shutdownNow()
        super.onDestroy()
    }

    private fun updateButtons() {
        val n = selected.size
        delBtn.isEnabled = n > 0
        delBtn.text = if (n > 0) "Löschen ($n)" else "Löschen"
        allBtn.isEnabled = shown.isNotEmpty()
        allBtn.text = if (shown.isNotEmpty() && n == shown.size) "Keine auswählen" else "Alle auswählen"
    }

    private fun toggleAll() {
        if (selected.size == shown.size) selected.clear() else selected.addAll(shown.map { it.uri })
        refresh()
    }

    private fun open(item: Store.Item) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(item.uri, Store.mime(cat.kind))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Keine App zum Öffnen gefunden.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openFolder() {
        val doc = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:" + cat.path)
        val tries = ArrayList<Intent>()
        // Dateien-App von Google / Android
        for (pkg in listOf("com.google.android.documentsui", "com.android.documentsui", null)) {
            tries.add(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                if (pkg != null) setPackage(pkg)
            })
        }
        // Manche Dateimanager (zum Beispiel Xiaomi) verstehen diese Form
        tries.add(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse("content://com.android.externalstorage.documents/document/primary%3A" + Uri.encode(cat.path)), "resource/folder")
        })
        // Zuletzt: Ordnerauswahl des Systems, geöffnet an diesem Ordner
        tries.add(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            putExtra(DocumentsContract.EXTRA_INITIAL_URI, doc)
        })
        for (i in tries) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // nächsten Weg versuchen
            }
        }
        Toast.makeText(this, "Dieses Handy öffnet den Ordner nicht direkt. Nutze die Liste hier.", Toast.LENGTH_LONG).show()
    }

    private fun confirmDelete() {
        val n = selected.size
        if (n == 0) return
        AlertDialog.Builder(this)
            .setTitle(if (n == 1) "Datei löschen?" else "$n Dateien löschen?")
            .setMessage("Sie werden endgültig gelöscht.")
            .setPositiveButton("Löschen") { _, _ -> deleteSelected() }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun deleteSelected() {
        val rest = ArrayList<Uri>()
        for (u in selected.toList()) {
            try {
                contentResolver.delete(u, null, null)
                selected.remove(u)
            } catch (e: Exception) {
                rest.add(u)
            }
        }
        if (rest.isNotEmpty()) {
            // Dateien, die nicht dieser App gehören (zum Beispiel aus einer früheren Version): Android fragt selbst nach.
            try {
                val pi = MediaStore.createDeleteRequest(contentResolver, rest)
                @Suppress("DEPRECATION")
                startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
                return
            } catch (e: Exception) {
                Toast.makeText(this, "Löschen bei ${rest.size} Datei(en) nicht möglich.", Toast.LENGTH_LONG).show()
            }
        }
        refresh()
    }

    private fun askRename(item: Store.Item) {
        val dot = item.name.lastIndexOf('.')
        val base = if (dot > 0) item.name.substring(0, dot) else item.name
        val ext = if (dot > 0) item.name.substring(dot) else ""
        val input = EditText(this).apply {
            setText(base)
            setSelection(base.length)
            setSingleLine(true)
        }
        val frame = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0) }
        frame.addView(input, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        AlertDialog.Builder(this)
            .setTitle("Datei umbenennen")
            .setMessage("Die Endung $ext bleibt erhalten.")
            .setView(frame)
            .setPositiveButton("Umbenennen") { _, _ -> rename(item, input.text.toString(), ext) }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun rename(item: Store.Item, wanted: String, ext: String) {
        val clean = wanted.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().trim('.')
        if (clean.isEmpty()) {
            Toast.makeText(this, "Bitte einen Namen eingeben.", Toast.LENGTH_LONG).show()
            return
        }
        val full = clean + ext
        if (full == item.name) return
        if (shown.any { it.name.equals(full, ignoreCase = true) }) {
            Toast.makeText(this, "Eine Datei mit diesem Namen gibt es schon.", Toast.LENGTH_LONG).show()
            return
        }
        applyRename(item.uri, full)
    }

    private fun applyRename(uri: Uri, name: String) {
        try {
            val cv = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, name) }
            contentResolver.update(uri, cv, null, null)
            Toast.makeText(this, "Umbenannt in $name", Toast.LENGTH_SHORT).show()
            refresh()
        } catch (e: SecurityException) {
            // Datei gehört nicht dieser App (zum Beispiel aus einer früheren Installation): Android fragt selbst nach.
            try {
                pendingUri = uri
                pendingName = name
                val pi = MediaStore.createWriteRequest(contentResolver, listOf(uri))
                @Suppress("DEPRECATION")
                startIntentSenderForResult(pi.intentSender, REQ_RENAME, null, 0, 0, 0)
            } catch (e2: Exception) {
                Toast.makeText(this, "Umbenennen ist bei dieser Datei nicht möglich.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Umbenennen hat nicht geklappt.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_RENAME) {
            val u = pendingUri
            val n = pendingName
            pendingUri = null
            pendingName = null
            if (resultCode == RESULT_OK && u != null && n != null) {
                try {
                    val cv = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, n) }
                    contentResolver.update(u, cv, null, null)
                    Toast.makeText(this, "Umbenannt in $n", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Umbenennen hat nicht geklappt.", Toast.LENGTH_LONG).show()
                }
            }
            refresh()
        }
        if (requestCode == REQ_DELETE) {
            selected.clear()
            refresh()
        }
    }
}
