package de.videoteiler

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Dateien eines Ordners: öffnen und einzeln löschen. */
class FileListActivity : Activity() {

    private val REQ_DELETE = 71
    private lateinit var cat: Store.Cat
    private lateinit var listBox: LinearLayout
    private lateinit var empty: TextView

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cat = Store.cats[intent.getIntExtra("cat", 0).coerceIn(0, Store.cats.size - 1)]
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        top.addView(
            Ui.header(this, cat.title, cat.path, Ui.TILE_OLIVE),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        )
        val folderBtn = Ui.button(this, "Ordner in der Dateien-App öffnen", false) { openFolder() }
        folderBtn.textSize = 14f
        top.addView(folderBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })
        empty = Ui.text(this, "Hier ist noch nichts gespeichert.", 15f, Ui.MUTED, false)
        empty.setPadding(dp(4), dp(12), dp(4), 0)
        top.addView(empty)
        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(12))
        }
        val scroll = ScrollView(this)
        scroll.addView(listBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        listBox.removeAllViews()
        val list = try { Store.items(this, cat) } catch (e: Exception) { emptyList() }
        empty.visibility = if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        for (item in list) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            Ui.panel(this, row)
            row.setPadding(dp(17), dp(9), dp(14), dp(15))
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                isClickable = true
                setOnClickListener { open(item) }
            }
            texts.addView(Ui.text(this, item.name, 15f, Ui.INK, true).apply { maxLines = 2 })
            texts.addView(Ui.text(this, Store.sizeText(item.size) + " · antippen zum Öffnen", 12f, Ui.MUTED, false))
            row.addView(texts, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            val del = Ui.text(this, "Löschen", 14f, Ui.GOLD, true).apply {
                setPadding(dp(12), dp(10), dp(8), dp(10))
                setOnClickListener { confirmDelete(item) }
            }
            row.addView(del)
            listBox.addView(row, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        }
    }

    private fun open(item: Store.Item) {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(item.uri, Store.mime(cat.kind))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            )
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Keine App zum Öffnen gefunden.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openFolder() {
        try {
            val uri = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:" + cat.path)
            startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, DocumentsContract.Document.MIME_TYPE_DIR)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Dieses Handy öffnet den Ordner nicht direkt. Nutze die Liste hier.", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmDelete(item: Store.Item) {
        AlertDialog.Builder(this)
            .setTitle("Datei löschen?")
            .setMessage(item.name + "\n\nSie wird endgültig gelöscht.")
            .setPositiveButton("Löschen") { _, _ -> delete(item.uri) }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun delete(uri: Uri) {
        try {
            contentResolver.delete(uri, null, null)
            refresh()
        } catch (e: SecurityException) {
            // Datei gehört nicht dieser App (zum Beispiel aus einer früheren Version): Android fragt selbst nach.
            try {
                val pi = MediaStore.createDeleteRequest(contentResolver, listOf(uri))
                @Suppress("DEPRECATION")
                startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
            } catch (e2: Exception) {
                Toast.makeText(this, "Löschen nicht möglich.", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Löschen nicht möglich.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_DELETE) refresh()
    }
}
