package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Dreht ein Video und bringt es ins Hochformat (9:16, wie WhatsApp-Status): zuschneiden oder mit schwarzen Rändern. */
class FormatActivity : Activity() {

    private val REQ = 101
    private val main = Handler(Looper.getMainLooper())
    private var src: Uri? = null
    private var info: SourceInfo? = null
    private var srcW = 0 // Maße des Bildes, wie es auf dem Handy aussieht
    private var srcH = 0
    private var frame: Bitmap? = null
    private var busy = false

    private var rot = 0 // Drehung im Uhrzeigersinn: 0, 90, 180, 270
    private var mode = 0 // 0 = Hochformat zuschneiden, 1 = Hochformat mit Rändern, 2 = Format beibehalten
    private var level = 0
    private var pos = 50 // Bildausschnitt 0..100 (links ... rechts bzw. oben ... unten)

    private class Level(val label: String, val shortSide: Int, val bitrate: Int)

    private val levels = listOf(
        Level("Klein (480p)", 480, 1_200_000),
        Level("Mittel (720p)", 720, 2_500_000),
        Level("Hoch (1080p)", 1080, 5_000_000)
    )

    private lateinit var infoText: TextView
    private lateinit var pickBtn: Button
    private lateinit var goBtn: Button
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var resultBox: LinearLayout
    private lateinit var preview: ImageView
    private lateinit var rotText: TextView
    private lateinit var posBox: LinearLayout
    private lateinit var posBar: SeekBar
    private val modeBtns = ArrayList<Button>()
    private val levelBtns = ArrayList<Button>()

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        top.addView(
            Ui.header(this, "Hochformat & Drehen", "Für WhatsApp-Status: Querformat in Hochformat bringen, Videos drehen.", Ui.TILE_TEAL),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        )
        pickBtn = Ui.button(this, "Video auswählen", true) { Ui.pickVideo(this, REQ) }
        top.addView(pickBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        infoText = Ui.text(this, "Noch kein Video gewählt.", 15f, Ui.INK, false)
        Ui.panel(this, infoText)
        top.addView(infoText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })

        // Format
        top.addView(Ui.text(this, "Format", 13f, Ui.MUTED, true), LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(14) })
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, n) in listOf("Hochformat zuschneiden", "Hochformat mit Rändern", "Format lassen").withIndex()) {
            val b = Button(this).apply {
                text = n
                textSize = 12f
                setOnClickListener { mode = i; refresh() }
            }
            modeBtns.add(b)
            modeRow.addView(b, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(6) })
        }
        top.addView(modeRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })

        // Drehen
        top.addView(Ui.text(this, "Drehen", 13f, Ui.MUTED, true), LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(14) })
        val rotRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = Ui.button(this, "↺ links", false) { rot = (rot + 270) % 360; refresh() }
        val right = Ui.button(this, "↻ rechts", false) { rot = (rot + 90) % 360; refresh() }
        for (b in listOf(left, right)) b.textSize = 14f
        rotRow.addView(left, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(6) })
        rotRow.addView(right, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        top.addView(rotRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        rotText = Ui.text(this, "", 12f, Ui.MUTED, false)
        top.addView(rotText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(4) })

        // Ausschnitt verschieben
        posBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        posBox.addView(Ui.text(this, "Bildausschnitt verschieben", 13f, Ui.MUTED, true))
        posBar = SeekBar(this).apply {
            max = 100
            progress = 50
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    pos = p
                    drawPreview()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        posBox.addView(posBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(4) })
        top.addView(posBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        // Vorschau
        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            visibility = View.GONE
        }
        top.addView(preview, LinearLayout.LayoutParams(Ui.MATCH, dp(300)).apply { topMargin = dp(12) })

        // Qualität
        top.addView(Ui.text(this, "Qualität", 13f, Ui.MUTED, true), LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(14) })
        val lvRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, l) in levels.withIndex()) {
            val b = Button(this).apply {
                text = l.label
                textSize = 13f
                setOnClickListener { level = i; refresh() }
            }
            levelBtns.add(b)
            lvRow.addView(b, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(6) })
        }
        top.addView(lvRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })

        goBtn = Ui.button(this, "Video speichern", true) { start() }
        goBtn.isEnabled = false
        top.addView(goBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        progressText = Ui.text(this, "", 13f, Ui.MUTED, false)
        top.addView(progressText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            visibility = View.GONE
        }
        top.addView(progressBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(resultBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        val scroll = android.widget.ScrollView(this)
        scroll.addView(top, android.view.ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
        Ui.incomingVideo(this)?.let { u -> window.decorView.post { onActivityResult(REQ, RESULT_OK, Intent().setData(u)) } }
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val inf = Splitter.readInfo(this, uri)
                src = uri
                info = inf
                readDims(uri)
                rot = 0
                pos = 50
                posBar.progress = 50
                infoText.text = "${inf.name}\nLänge ${Ui.fmt(inf.durationUs / 1_000_000L)} Min." +
                    (if (srcW > 0) " · ${srcW}×${srcH}" else "")
                // Querformat: gleich auf Hochformat voreinstellen
                mode = if (srcW > srcH) 0 else 2
            } catch (e: Exception) {
                src = null
                info = null
                frame = null
                infoText.text = "Dieses Video konnte nicht gelesen werden."
            }
            resultBox.removeAllViews()
            progressText.text = ""
            refresh()
        }
    }

    private fun readDims(uri: Uri) {
        srcW = 0
        srcH = 0
        frame = null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rr = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rr == 90 || rr == 270) { srcW = h; srcH = w } else { srcW = w; srcH = h }
            val durMs = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L)
            val bmp = r.getFrameAtTime(durMs * 500L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            if (bmp != null) {
                val f = 640f / maxOf(bmp.width, bmp.height)
                frame = if (f < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt(), (bmp.height * f).toInt(), true) else bmp
            }
        } catch (e: Exception) {
            // ohne Vorschau weiter
        } finally {
            r.release()
        }
    }

    /** Maße nach dem Drehen. */
    private fun rw() = if (rot % 180 == 0) srcW else srcH
    private fun rh() = if (rot % 180 == 0) srcH else srcW

    private fun refresh() {
        for ((i, b) in modeBtns.withIndex()) {
            Ui.style3d(this, b, i == mode, 12)
            b.textSize = 12f
            b.setPadding(dp(6), dp(12), dp(8), dp(18))
        }
        for ((i, b) in levelBtns.withIndex()) {
            Ui.style3d(this, b, i == level, 12)
            b.textSize = 13f
            b.setPadding(dp(8), dp(12), dp(10), dp(18))
        }
        rotText.text = when (rot) {
            0 -> "Nicht gedreht."
            90 -> "Um 90° nach rechts gedreht."
            180 -> "Um 180° gedreht."
            else -> "Um 90° nach links gedreht."
        }
        val has = src != null && srcW > 0
        val cropWanted = has && mode == 0 && needsCrop()
        posBox.visibility = if (cropWanted) View.VISIBLE else View.GONE
        goBtn.isEnabled = has && !busy && !(mode == 2 && rot == 0)
        if (has && mode == 2 && rot == 0) progressText.text = "Wähle ein Hochformat oder drehe das Video."
        else if (progressText.text.toString().startsWith("Wähle ein Hochformat")) progressText.text = ""
        drawPreview()
    }

    private fun needsCrop(): Boolean = rw().toDouble() / rh() != 9.0 / 16.0

    /** Ausschnitt in Werten von -1 bis 1 (links, rechts, unten, oben) für den Zuschnitt auf 9:16, oder null. */
    private fun cropRect(): FloatArray? {
        if (mode != 0 || srcW <= 0) return null
        val ta = 9.0 / 16.0
        val w = rw().toDouble()
        val h = rh().toDouble()
        val p = pos / 100.0
        return if (w / h > ta) {
            val f = (h * ta) / w
            val l = -1.0 + 2.0 * p * (1.0 - f)
            floatArrayOf(l.toFloat(), (l + 2.0 * f).toFloat(), -1f, 1f)
        } else {
            val g = (w / ta) / h
            val b = -1.0 + 2.0 * p * (1.0 - g)
            floatArrayOf(-1f, 1f, b.toFloat(), (b + 2.0 * g).toFloat())
        }
    }

    private fun drawPreview() {
        val fr = frame
        if (fr == null || srcW <= 0) {
            preview.visibility = View.GONE
            return
        }
        val m = Matrix()
        m.postRotate(rot.toFloat())
        val rotated = Bitmap.createBitmap(fr, 0, 0, fr.width, fr.height, m, true)
        val outW: Int
        val outH: Int
        if (mode == 2) {
            outW = rotated.width
            outH = rotated.height
        } else {
            outW = 270
            outH = 480
        }
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.BLACK)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        val crop = cropRect()
        if (mode == 2) {
            c.drawBitmap(rotated, 0f, 0f, paint)
        } else if (crop != null) {
            // Ausschnitt aus dem gedrehten Bild
            val l = ((crop[0] + 1f) / 2f * rotated.width).toInt().coerceIn(0, rotated.width - 1)
            val r = ((crop[1] + 1f) / 2f * rotated.width).toInt().coerceIn(l + 1, rotated.width)
            val bt = ((1f - crop[3]) / 2f * rotated.height).toInt().coerceIn(0, rotated.height - 1)
            val bb = ((1f - crop[2]) / 2f * rotated.height).toInt().coerceIn(bt + 1, rotated.height)
            val srcRect = android.graphics.Rect(l, bt, r, bb)
            c.drawBitmap(rotated, srcRect, android.graphics.Rect(0, 0, outW, outH), paint)
        } else {
            // mit Rändern
            val s = minOf(outW.toFloat() / rotated.width, outH.toFloat() / rotated.height)
            val dw = (rotated.width * s).toInt()
            val dh = (rotated.height * s).toInt()
            val x = (outW - dw) / 2
            val y = (outH - dh) / 2
            c.drawBitmap(rotated, null, android.graphics.Rect(x, y, x + dw, y + dh), paint)
        }
        preview.setImageBitmap(out)
        preview.visibility = View.VISIBLE
    }

    private fun start() {
        val uri = src ?: return
        val inf = info ?: return
        if (busy) return
        busy = true
        pickBtn.isEnabled = false
        goBtn.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        resultBox.removeAllViews()
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = false
        progressBar.max = 100
        progressBar.progress = 0
        progressText.text = "Bearbeite das Video (dauert je nach Länge) …"

        val base = inf.name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
            .trim('_')
            .take(40)
            .ifEmpty { "Video" }
        val tmp = File(cacheDir, "format.tmp.mp4")
        val app = applicationContext
        val name = "${base}_" + (if (mode == 2) "gedreht" else "hochformat") + ".mp4"
        val l = levels[level]

        var outW = 0
        var outH = 0
        if (mode != 2) {
            outW = l.shortSide
            outH = (l.shortSide * 16 / 9).let { if (it % 2 != 0) it + 1 else it }
        } else {
            // Format bleibt: nur Größe an die Qualitätsstufe anpassen (nie vergrößern)
            val shortSide = minOf(rw(), rh())
            if (shortSide > l.shortSide) {
                var h = Math.round(rh() * (l.shortSide.toDouble() / shortSide)).toInt()
                if (h % 2 != 0) h += 1
                outH = h
            }
        }

        Transcoder.reframe(this, uri, tmp, rot, cropRect(), outW, outH, l.bitrate,
            onProgress = { pct -> progressBar.progress = pct },
            onDone = { err ->
                if (err != null) {
                    tmp.delete()
                    done(null, "Fehler: $err")
                } else {
                    Thread {
                        var out: Uri? = null
                        var msg: String? = null
                        try {
                            out = Splitter.createOutput(app, name)
                            Splitter.copyToGallery(app, tmp, out)
                            Splitter.finish(app, out)
                        } catch (e: Exception) {
                            msg = "Fehler: ${e.message ?: e.javaClass.simpleName}"
                            out?.let { Splitter.discard(app, it) }
                            out = null
                        }
                        tmp.delete()
                        val o = out
                        val m = msg
                        main.post { done(o, m ?: "Fertig: $name in Filme/Video-Teiler gespeichert.") }
                    }.start()
                }
            }
        )
    }

    private fun done(uri: Uri?, message: String) {
        busy = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        pickBtn.isEnabled = true
        progressBar.visibility = View.GONE
        progressText.text = message
        refresh()
        progressText.text = message
        resultBox.removeAllViews()
        if (uri != null) {
            val play = Ui.button(this, "Ansehen", false) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "video/mp4")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    })
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this, "Keine App zum Abspielen gefunden.", Toast.LENGTH_LONG).show()
                }
            }
            val share = Ui.button(this, "Teilen", false) {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "Teilen mit"))
            }
            play.textSize = 14f
            share.textSize = 14f
            resultBox.addView(play, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
            resultBox.addView(share, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        }
    }
}
