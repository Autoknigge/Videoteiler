package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Schneidet einen Ausschnitt (Anfang bis Ende) aus einem Video und speichert ihn unter Filme/Video-Teiler. */
class TrimActivity : Activity() {

    private val REQ = 81
    private val main = Handler(Looper.getMainLooper())
    private var src: Uri? = null
    private var info: SourceInfo? = null
    private var busy = false
    private var durSec = 0
    private var startSec = 0
    private var endSec = 0
    private var fixing = false
    private var frameSeq = 0
    private var dispW = 0
    private var dispH = 0
    private var level = 0 // 0 = Original, 1 = Hoch 1080p, 2 = Mittel 720p, 3 = Klein 480p

    private class Level(val label: String, val shortSide: Int, val bitrate: Int)

    private val levels = listOf(
        Level("Original", 0, 0),
        Level("Hoch 1080p", 1080, 5_000_000),
        Level("Mittel 720p", 720, 2_500_000),
        Level("Klein 480p", 480, 1_200_000)
    )
    private val levelBtns = ArrayList<Button>()
    private var speedIdx = 0 // 0 = normal, 1 = halbe Geschwindigkeit, 2 = doppelte Geschwindigkeit
    private val speedBtns = ArrayList<Button>()
    private val speeds = listOf("Normal", "½ langsamer", "2× schneller")
    private val speedVals = floatArrayOf(1f, 0.5f, 2f)

    private lateinit var infoText: TextView
    private lateinit var pickBtn: Button
    private lateinit var goBtn: Button
    private lateinit var progressText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var resultBox: LinearLayout
    private lateinit var sliderBox: LinearLayout
    private lateinit var startLabel: TextView
    private lateinit var endLabel: TextView
    private lateinit var lenLabel: TextView
    private lateinit var startBar: SeekBar
    private lateinit var endBar: SeekBar
    private lateinit var startImg: ImageView
    private lateinit var endImg: ImageView

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        top.addView(
            Ui.header(this, "Kürzen & Verkleinern", "Ausschnitt wählen, Datei kleiner machen, Tempo ändern.", Ui.TILE_AMBER),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        )
        pickBtn = Ui.button(this, "Video auswählen", true) { Ui.pickVideo(this, REQ) }
        top.addView(pickBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(14) })

        infoText = Ui.text(this, "Noch kein Video gewählt.", 15f, Ui.INK, false)
        Ui.panel(this, infoText)
        top.addView(infoText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })

        sliderBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        Ui.panel(this, sliderBox)
        startLabel = Ui.text(this, "Anfang: 0:00", 15f, Ui.INK, true)
        sliderBox.addView(startLabel)
        startBar = bar { v -> onStartChanged(v) }
        sliderBox.addView(startBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        endLabel = Ui.text(this, "Ende: 0:00", 15f, Ui.INK, true)
        sliderBox.addView(endLabel, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(8) })
        endBar = bar { v -> onEndChanged(v) }
        sliderBox.addView(endBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        lenLabel = Ui.text(this, "", 13f, Ui.MUTED, false)
        sliderBox.addView(lenLabel, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(6) })
        val imgRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startImg = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        endImg = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        imgRow.addView(startImg, LinearLayout.LayoutParams(0, dp(110), 1f).apply { rightMargin = dp(6) })
        imgRow.addView(endImg, LinearLayout.LayoutParams(0, dp(110), 1f))
        sliderBox.addView(imgRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        top.addView(sliderBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        top.addView(Ui.text(this, "Qualität / Dateigröße", 13f, Ui.MUTED, true), LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(14) })
        val lvRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, l) in levels.withIndex()) {
            val b = Button(this).apply {
                text = l.label
                textSize = 12f
                setOnClickListener { level = i; styleLevels() }
            }
            levelBtns.add(b)
            lvRow.addView(b, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(5) })
        }
        top.addView(lvRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        styleLevels()

        top.addView(Ui.text(this, "Geschwindigkeit", 13f, Ui.MUTED, true), LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = dp(14) })
        val spRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, n) in speeds.withIndex()) {
            val b = Button(this).apply {
                text = n
                textSize = 13f
                setOnClickListener { speedIdx = i; styleSpeeds() }
            }
            speedBtns.add(b)
            spRow.addView(b, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(5) })
        }
        top.addView(spRow, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(6) })
        styleSpeeds()

        goBtn = Ui.button(this, "Speichern", true) { start() }
        goBtn.isEnabled = false
        top.addView(goBtn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })

        progressText = Ui.text(this, "", 13f, Ui.MUTED, false)
        top.addView(progressText, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            visibility = View.GONE
        }
        top.addView(progressBar, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(resultBox, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(8) })

        val scroll = android.widget.ScrollView(this)
        scroll.addView(top, android.view.ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
        Ui.incomingVideo(this)?.let { u -> window.decorView.post { onActivityResult(REQ, RESULT_OK, Intent().setData(u)) } }
    }

    private fun styleLevels() {
        for ((i, b) in levelBtns.withIndex()) {
            Ui.style3d(this, b, i == level, 12)
            b.textSize = 12f
            b.setPadding(dp(5), dp(12), dp(7), dp(18))
        }
    }

    private fun styleSpeeds() {
        for ((i, b) in speedBtns.withIndex()) {
            Ui.style3d(this, b, i == speedIdx, 12)
            b.textSize = 13f
            b.setPadding(dp(5), dp(12), dp(7), dp(18))
        }
    }

    private fun readDims(uri: Uri) {
        dispW = 0
        dispH = 0
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { dispW = h; dispH = w } else { dispW = w; dispH = h }
        } catch (e: Exception) {
            // Maße unbekannt
        } finally {
            r.release()
        }
    }

    private fun targetHeight(): Int {
        val l = levels[level]
        val shortSide = minOf(dispW, dispH)
        if (l.shortSide == 0 || shortSide <= 0 || shortSide <= l.shortSide) return 0
        var h = Math.round(maxOf(dispW, dispH) * (l.shortSide.toDouble() / shortSide)).toInt()
        // Bei Hochformat ist die Höhe die lange Seite, bei Querformat die kurze: Höhe des Ergebnisses berechnen.
        h = if (dispH >= dispW) h else l.shortSide
        if (h % 2 != 0) h += 1
        return h
    }

    private fun bar(onChange: (Int) -> Unit): SeekBar = SeekBar(this).apply {
        progressTintList = ColorStateList.valueOf(Ui.ACCENT)
        thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fixing) onChange(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {
                loadFrames()
            }
        })
    }

    private fun onStartChanged(v: Int) {
        startSec = v
        if (endSec <= startSec) {
            endSec = minOf(durSec, startSec + 1)
            fixing = true
            endBar.progress = endSec
            fixing = false
        }
        labels()
    }

    private fun onEndChanged(v: Int) {
        endSec = v
        if (startSec >= endSec) {
            startSec = maxOf(0, endSec - 1)
            fixing = true
            startBar.progress = startSec
            fixing = false
        }
        labels()
    }

    private fun labels() {
        startLabel.text = "Anfang: ${Ui.fmt(startSec.toLong())}"
        endLabel.text = "Ende: ${Ui.fmt(endSec.toLong())}"
        lenLabel.text = "Länge des Ausschnitts: ${Ui.fmt((endSec - startSec).toLong())}"
    }

    /** Zeigt das Bild am Anfang und am Ende des Ausschnitts. */
    private fun loadFrames() {
        val uri = src ?: return
        val s = startSec
        val e = endSec
        val seq = ++frameSeq
        val app = applicationContext
        Thread {
            var a: Bitmap? = null
            var b: Bitmap? = null
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(app, uri)
                a = scaled(r.getFrameAtTime(s * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC))
                b = scaled(r.getFrameAtTime(maxOf(0, e - 1) * 1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC))
            } catch (ex: Exception) {
                // keine Vorschau
            } finally {
                r.release()
            }
            val fa = a
            val fb = b
            main.post {
                if (seq == frameSeq) {
                    startImg.setImageBitmap(fa)
                    endImg.setImageBitmap(fb)
                }
            }
        }.start()
    }

    private fun scaled(bm: Bitmap?): Bitmap? {
        if (bm == null) return null
        val h = 220
        val w = maxOf(1, bm.width * h / maxOf(1, bm.height))
        return Bitmap.createScaledBitmap(bm, w, h, true)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val inf = Splitter.readInfo(this, uri)
                src = uri
                info = inf
                readDims(uri)
                durSec = (inf.durationUs / 1_000_000L).toInt()
                infoText.text = "${inf.name}\nLänge ${Ui.fmt(durSec.toLong())} Min."
                if (durSec >= 2) {
                    fixing = true
                    startBar.max = durSec
                    endBar.max = durSec
                    startSec = 0
                    endSec = durSec
                    startBar.progress = 0
                    endBar.progress = durSec
                    fixing = false
                    labels()
                    sliderBox.visibility = View.VISIBLE
                    loadFrames()
                    goBtn.isEnabled = !busy
                } else {
                    sliderBox.visibility = View.GONE
                    goBtn.isEnabled = false
                }
            } catch (e: Exception) {
                src = null
                info = null
                sliderBox.visibility = View.GONE
                goBtn.isEnabled = false
                infoText.text = "Dieses Video konnte nicht gelesen werden."
            }
            resultBox.removeAllViews()
            progressText.text = ""
        }
    }

    private fun start() {
        val uri = src ?: return
        val inf = info ?: return
        if (busy) return
        busy = true
        pickBtn.isEnabled = false
        goBtn.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        resultBox.removeAllViews()
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = false
        progressBar.max = 100
        progressBar.progress = 0
        progressText.text = "Bearbeite das Video (dauert je nach Länge) …"

        val base = inf.name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
            .trim('_')
            .take(40)
            .ifEmpty { "Video" }
        val tmp = File(cacheDir, "ausschnitt.tmp.mp4")
        val app = applicationContext
        val trimmed = startSec > 0 || endSec < durSec
        val name = "${base}" + (if (trimmed) "_Ausschnitt" else "") + (if (level > 0) "_klein" else "") +
            (if (speedIdx == 1) "_langsam" else if (speedIdx == 2) "_schnell" else "") +
            (if (!trimmed && level == 0 && speedIdx == 0) "_Kopie" else "") + ".mp4"
        val l = levels[level]

        Transcoder.run(this, uri, tmp, startSec * 1000L, endSec * 1000L,
            onProgress = { pct -> progressBar.progress = pct },
            onDone = { err ->
                if (err != null) {
                    tmp.delete()
                    done(null, "Fehler: $err")
                } else {
                    Thread {
                        var out: Uri? = null
                        var msg: String? = null
                        try {
                            out = Splitter.createOutput(app, name)
                            Splitter.copyToGallery(app, tmp, out)
                            Splitter.finish(app, out)
                        } catch (e: Exception) {
                            msg = "Fehler: ${e.message ?: e.javaClass.simpleName}"
                            out?.let { Splitter.discard(app, it) }
                            out = null
                        }
                        tmp.delete()
                        val o = out
                        val m = msg
                        main.post { done(o, m ?: "Fertig: $name in Filme/Video-Teiler gespeichert.") }
                    }.start()
                }
            },
            targetHeight = targetHeight(),
            videoBitrate = l.bitrate,
            speed = speedVals[speedIdx]
        )
    }

    private fun done(uri: Uri?, message: String) {
        busy = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        pickBtn.isEnabled = true
        goBtn.isEnabled = src != null && durSec >= 2
        progressBar.visibility = View.GONE
        progressText.text = message
        resultBox.removeAllViews()
        if (uri != null) {
            val play = Ui.button(this, "Ansehen", false) {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "video/mp4")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    })
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this, "Keine App zum Abspielen gefunden.", Toast.LENGTH_LONG).show()
                }
            }
            val share = Ui.button(this, "Teilen", false) {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, "Teilen mit"))
            }
            play.textSize = 14f
            share.textSize = 14f
            resultBox.addView(play, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { rightMargin = dp(8) })
            resultBox.addView(share, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        }
    }
}
