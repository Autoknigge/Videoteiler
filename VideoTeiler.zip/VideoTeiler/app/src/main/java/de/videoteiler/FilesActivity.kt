package de.videoteiler

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Zeigt die Ordner, in denen die App Videos, Töne und Fotos ablegt, und öffnet sie direkt. */
class FilesActivity : Activity() {

    private class Cat(val icon: String, val title: String, val path: String, val kind: Int) {
        lateinit var info: TextView
    }

    private val cats = listOf(
        Cat("🎞️", "Video", "Movies/Video-Teiler", 0),
        Cat("🎧", "Audio", "Music/Video-Teiler", 1),
        Cat("📸", "Foto (Status)", "Pictures/Status-Sicherer", 2),
        Cat("📹", "Video (Status)", "Movies/Status-Sicherer", 0)
    )

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        top.addView(
            Ui.header(this, "Gespeicherte Daten ansehen", "Antippen öffnet den Ordner. Lange drücken zeigt die Liste hier.", Ui.TILE_OLIVE),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        )
        for (c in cats) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                setOnClickListener { openFolder(c) }
                setOnLongClickListener { showList(c); true }
            }
            Ui.panel(this, row)
            row.addView(Ui.text(this, c.icon, 26f, Ui.GOLD, false), LinearLayout.LayoutParams(dp(42), Ui.WRAP))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(Ui.text(this, c.title, 17f, Ui.GOLD, true))
            c.info = Ui.text(this, "", 13f, Ui.MUTED, false)
            texts.addView(c.info)
            row.addView(texts, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            row.addView(Ui.text(this, "›", 24f, Ui.GOLD, true))
            Ui.pressEffect(this, row)
            top.addView(row, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })
        }
        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
    }

    override fun onResume() {
        super.onResume()
        for (c in cats) {
            val n = try { items(c).size } catch (e: Exception) { 0 }
            c.info.text = (if (n == 0) "Noch leer" else if (n == 1) "1 Datei" else "$n Dateien") + " · " + c.path
        }
    }

    private fun collection(kind: Int): Uri = when (kind) {
        0 -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        1 -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        else -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    }

    private fun mime(kind: Int) = when (kind) { 0 -> "video/*"; 1 -> "audio/*"; else -> "image/*" }

    /** Dateien dieser Kategorie (Name und Adresse), neueste zuerst. */
    private fun items(c: Cat): List<Pair<String, Uri>> {
        val out = ArrayList<Pair<String, Uri>>()
        contentResolver.query(
            collection(c.kind),
            arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME),
            "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
            arrayOf(c.path + "/%"),
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { cur ->
            while (cur.moveToNext() && out.size < 300) {
                out.add(cur.getString(1) to ContentUris.withAppendedId(collection(c.kind), cur.getLong(0)))
            }
        }
        return out
    }

    private fun openFolder(c: Cat) {
        if (items(c).isEmpty()) {
            Toast.makeText(this, "Hier ist noch nichts gespeichert.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val uri = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:" + c.path)
            startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, DocumentsContract.Document.MIME_TYPE_DIR)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            )
        } catch (e: Exception) {
            // Keine App, die den Ordner öffnet: Liste in der App zeigen.
            showList(c)
        }
    }

    private fun showList(c: Cat) {
        val list = items(c)
        if (list.isEmpty()) {
            Toast.makeText(this, "Hier ist noch nichts gespeichert.", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(c.title)
            .setItems(list.map { it.first }.toTypedArray()) { _, i ->
                try {
                    startActivity(
                        Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(list[i].second, mime(c.kind))
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                    )
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this, "Keine App zum Öffnen gefunden.", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Schließen", null)
            .show()
    }
}
