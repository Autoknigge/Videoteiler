package de.videoteiler

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** Übersicht der Ordner, in denen die App Videos, Töne und Fotos ablegt. */
class FilesActivity : Activity() {

    private val infos = ArrayList<TextView>()

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        top.addView(
            Ui.header(this, "Gespeicherte Daten ansehen", "Ordner antippen: ansehen, öffnen oder löschen.", Ui.TILE_MOSS),
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        )
        for ((index, c) in Store.cats.withIndex()) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                setOnClickListener {
                    startActivity(Intent(this@FilesActivity, FileListActivity::class.java).putExtra("cat", index))
                }
            }
            Ui.panel(this, row)
            row.addView(Ui.text(this, c.icon, 26f, Ui.GOLD, false), LinearLayout.LayoutParams(dp(42), Ui.WRAP))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(Ui.text(this, c.title, 17f, Ui.GOLD, true))
            val info = Ui.text(this, "", 13f, Ui.MUTED, false)
            infos.add(info)
            texts.addView(info)
            row.addView(texts, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            row.addView(Ui.text(this, "›", 24f, Ui.GOLD, true))
            Ui.pressEffect(this, row)
            top.addView(row, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { topMargin = dp(12) })
        }
        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        setContentView(root)
        Ui.adFooter(this, root)
        Ui.bars(this)
    }

    override fun onResume() {
        super.onResume()
        for ((i, c) in Store.cats.withIndex()) {
            val n = try { Store.items(this, c).size } catch (e: Exception) { 0 }
            infos[i].text = (if (n == 0) "Noch leer" else if (n == 1) "1 Datei" else "$n Dateien") + " · " + c.path
        }
    }
}
