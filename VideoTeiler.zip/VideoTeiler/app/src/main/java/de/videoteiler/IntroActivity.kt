package de.videoteiler

import android.animation.ValueAnimator
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.window.OnBackInvokedDispatcher
import android.widget.LinearLayout
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.widget.TextView
import android.view.animation.LinearInterpolator

/**
 * Start-Ausgabe: kurze Anzeige beim Start. Oben steht "Weiter zu Videoteiler" mit einem Balken,
 * der sich in [WAIT_MS] füllt; danach lässt sich der Knopf antippen.
 */
class IntroActivity : Activity() {

    private val WAIT_MS = 5000L
    private var ready = false
    private var anim: ValueAnimator? = null

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)

        // Oben: Knopf mit Zeitverlauf
        val label = Ui.text(this, "Weiter zu Videoteiler  ›", 18f, Ui.MUTED, true).apply { gravity = Gravity.CENTER }
        val bar = WaitBar(this)
        val waitFace = intArrayOf(Color.parseColor("#2AA872"), Color.parseColor("#13734A"), Color.parseColor("#08402A"))
        val readyFace = intArrayOf(Color.parseColor("#FFEDA8"), Color.parseColor("#DDB84C"), Color.parseColor("#9A7220"))
        val button = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.tile3d(this@IntroActivity, Ui.SURFACE, waitFace)
            setPadding(dp(21), dp(16), dp(24), dp(23))
            addView(label, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
            addView(bar, LinearLayout.LayoutParams(Ui.MATCH, dp(24)).apply { topMargin = dp(8) })
            setOnClickListener { if (ready) finish() }
        }
        val top = LinearLayout(this).apply { setPadding(dp(20), dp(14), dp(20), 0) }
        top.addView(button, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        // Mitte: das Logo, während die Anzeige lädt
        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(40), 0, dp(40), 0)
        }
        middle.addView(
            android.widget.ImageView(this).apply {
                setImageResource(R.drawable.logo_voll)
                adjustViewBounds = true
            },
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)
        )
        root.addView(middle, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        setContentView(root)
        Ui.bars(this)
        Ads.showIntroAd(this)

        anim = ValueAnimator.ofInt(0, 1000).apply {
            duration = WAIT_MS
            interpolator = LinearInterpolator()
            addUpdateListener { bar.progress = (it.animatedValue as Int) / 1000f }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    ready = true
                    label.setTextColor(Ui.ON_ACCENT)
                    button.background = Ui.tile3d(this@IntroActivity, Ui.ACCENT, readyFace)
                    bar.done = true
                }
            })
            start()
        }

        // Zurück-Taste erst nach der Wartezeit.
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) {
                if (ready) finish()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (ready) super.onBackPressed()
    }

    override fun onDestroy() {
        anim?.cancel()
        super.onDestroy()
    }
}

/** Zeitbalken in 3D: goldene Röhre, die sich nach rechts füllt, vorn mit einem 3D-Pfeil. */
class WaitBar(ctx: Context) : View(ctx) {
    var progress = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var done = false
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bodyTop = h * 0.30f
        val bodyBot = h * 0.70f
        val rr = (bodyBot - bodyTop) / 2f
        val arrowLen = h * 0.95f

        // Rinne (vertieft)
        p.shader = LinearGradient(0f, bodyTop, 0f, bodyBot,
            intArrayOf(Color.parseColor("#02140C"), Color.parseColor("#0A3622"), Color.parseColor("#1B6A47")), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(0f, bodyTop, w, bodyBot), rr, rr, p)

        val tip = maxOf(arrowLen, progress * w)
        val x0 = tip - arrowLen
        val light: Int; val mid: Int; val dark: Int
        if (done) {
            light = Color.parseColor("#1B6A47"); mid = Color.parseColor("#0C3F29"); dark = Color.parseColor("#052619")
        } else {
            light = Color.parseColor("#FFF0B0"); mid = Color.parseColor("#E0B93E"); dark = Color.parseColor("#8A6418")
        }
        // Röhre
        if (x0 > 0f) {
            p.shader = LinearGradient(0f, bodyTop, 0f, bodyBot, intArrayOf(light, mid, dark), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            c.drawRoundRect(RectF(0f, bodyTop, x0 + rr, bodyBot), rr, rr, p)
        }
        // Pfeil: Schatten, obere helle und untere dunkle Hälfte
        val cy = h / 2f
        val sh = 2f * d
        p.shader = null
        p.color = Color.parseColor("#66000000")
        c.drawPath(tri(x0, 0f + sh, tip, cy + sh, x0, h + sh), p)
        p.shader = LinearGradient(x0, 0f, tip, cy, light, mid, Shader.TileMode.CLAMP)
        c.drawPath(tri(x0, 0f, tip, cy, x0, cy), p)
        p.shader = LinearGradient(x0, cy, tip, h, mid, dark, Shader.TileMode.CLAMP)
        c.drawPath(tri(x0, cy, tip, cy, x0, h), p)
        p.shader = null
    }

    private fun tri(ax: Float, ay: Float, bx: Float, by: Float, cx: Float, cy: Float): Path =
        Path().apply { moveTo(ax, ay); lineTo(bx, by); lineTo(cx, cy); close() }
}
