package de.videoteiler

import android.animation.ValueAnimator
import android.app.Activity
import android.content.res.ColorStateList
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.window.OnBackInvokedDispatcher
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.view.animation.LinearInterpolator

/**
 * Start-Ausgabe: kurze Anzeige beim Start. Oben steht "Weiter zu Videoteiler" mit einem Balken,
 * der sich in [WAIT_MS] füllt; danach lässt sich der Knopf antippen.
 */
class IntroActivity : Activity() {

    private val WAIT_MS = 5000L
    private var ready = false
    private var anim: ValueAnimator? = null

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)

        // Oben: Knopf mit Zeitverlauf
        val label = Ui.text(this, "Weiter zu Videoteiler  ›", 18f, Ui.MUTED, true).apply { gravity = Gravity.CENTER }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = 0
            progressTintList = ColorStateList.valueOf(Ui.GOLD)
            progressBackgroundTintList = ColorStateList.valueOf(Ui.LINE)
        }
        val button = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(this@IntroActivity, Ui.SURFACE, 14)
            setPadding(dp(16), dp(14), dp(16), dp(12))
            addView(label, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
            addView(bar, LinearLayout.LayoutParams(Ui.MATCH, dp(8)).apply { topMargin = dp(10) })
            setOnClickListener { if (ready) finish() }
        }
        val top = LinearLayout(this).apply { setPadding(dp(20), dp(14), dp(20), 0) }
        top.addView(button, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        root.addView(top, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))

        // Mitte: Anzeige
        val middle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        middle.addView(
            Ui.text(this, "Anzeige", 12f, Ui.MUTED, false).apply { gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply { bottomMargin = dp(8) }
        )
        root.addView(middle, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))

        setContentView(root)
        Ui.bars(this)
        Ads.attachIntro(this, middle)

        anim = ValueAnimator.ofInt(0, 1000).apply {
            duration = WAIT_MS
            interpolator = LinearInterpolator()
            addUpdateListener { bar.progress = it.animatedValue as Int }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    ready = true
                    label.setTextColor(Ui.ON_ACCENT)
                    button.background = Ui.round(this@IntroActivity, Ui.ACCENT, 14)
                    bar.progressTintList = ColorStateList.valueOf(Ui.ON_ACCENT)
                }
            })
            start()
        }

        // Zurück-Taste erst nach der Wartezeit.
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) {
                if (ready) finish()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (ready) super.onBackPressed()
    }

    override fun onDestroy() {
        anim?.cancel()
        super.onDestroy()
    }
}
