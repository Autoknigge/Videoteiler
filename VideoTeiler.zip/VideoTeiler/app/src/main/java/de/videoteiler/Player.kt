package de.videoteiler

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ResolveInfo
import android.net.Uri
import android.widget.Button
import android.widget.Toast
import android.app.AlertDialog

/**
 * Merkt sich den zuletzt gewählten Player (je für Video, Audio, Foto) und öffnet damit direkt.
 * Über den Knopf "Player ändern" kann man jederzeit einen anderen wählen.
 */
object Player {
    private fun kind(mime: String) = mime.substringBefore('/')
    private fun prefs(a: Activity) = a.getSharedPreferences("player", 0)

    private fun probe(uri: Uri?, mime: String) = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri ?: Uri.parse("content://media/external/file/1"), mime)
    }

    private fun apps(a: Activity, uri: Uri?, mime: String): List<ResolveInfo> =
        a.packageManager.queryIntentActivities(probe(uri, mime), 0)
            .filter { it.activityInfo.packageName != a.packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(a.packageManager).toString().lowercase() }

    private fun start(a: Activity, uri: Uri, mime: String, pkg: String?) {
        a.startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (pkg != null) setPackage(pkg)
        })
    }

    /** Öffnet mit dem zuletzt gewählten Player; gibt es keinen, erscheint die Auswahl. */
    fun open(a: Activity, uri: Uri, mime: String) {
        val saved = prefs(a).getString(kind(mime), null)
        if (saved != null) {
            try {
                start(a, uri, mime, saved)
                return
            } catch (e: Exception) {
                prefs(a).edit().remove(kind(mime)).apply() // Player nicht mehr vorhanden
            }
        }
        choose(a, uri, mime)
    }

    /** Zeigt die Liste der Player. Mit uri wird danach gleich abgespielt, ohne uri wird nur gemerkt. */
    fun choose(a: Activity, uri: Uri?, mime: String) {
        val list = apps(a, uri, mime)
        if (list.isEmpty()) {
            Toast.makeText(a, "Keine App zum Abspielen gefunden.", Toast.LENGTH_LONG).show()
            return
        }
        val saved = prefs(a).getString(kind(mime), null)
        val names = list.map {
            val n = it.loadLabel(a.packageManager).toString()
            if (it.activityInfo.packageName == saved) "$n  ✓" else n
        }.toTypedArray()
        AlertDialog.Builder(a)
            .setTitle("Player wählen")
            .setItems(names) { _, which ->
                val pkg = list[which].activityInfo.packageName
                prefs(a).edit().putString(kind(mime), pkg).apply()
                if (uri != null) {
                    try {
                        start(a, uri, mime, pkg)
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(a, "Das hat nicht geklappt.", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(a, "Gemerkt: " + list[which].loadLabel(a.packageManager), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    fun button(a: Activity, uri: Uri?, mime: String): Button =
        Ui.button(a, "Player ändern", false) { choose(a, uri, mime) }.apply { textSize = 13f }
}
