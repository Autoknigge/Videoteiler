package de.videoteiler

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer

/** Setzt die Videospur eines Videos und die Tonspur einer AAC-Datei zu einer MP4-Datei zusammen. */
object Merger {

    private fun findTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        return -1
    }

    /**
     * [videoSrc] liefert Bild (muss H.264/H.265/MPEG-4 sein), [audioSrc] liefert den Ton (AAC).
     * Das Ergebnis ist so lang wie das Video; ist der Ton länger, wird er abgeschnitten.
     */
    fun mux(ctx: Context, videoSrc: Uri, audioSrc: Uri, out: File) {
        if (out.exists()) out.delete()
        val vx = MediaExtractor()
        val ax = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            vx.setDataSource(ctx, videoSrc, null)
            ax.setDataSource(ctx, audioSrc, null)
            val vi = findTrack(vx, "video/")
            val ai = findTrack(ax, "audio/")
            if (vi < 0) throw IllegalStateException("Keine Videospur gefunden.")
            if (ai < 0) throw IllegalStateException("Keine Tonspur gefunden.")

            val vf = vx.getTrackFormat(vi)
            val af = ax.getTrackFormat(ai)
            var rotation = 0
            var videoDurUs = if (vf.containsKey(MediaFormat.KEY_DURATION)) vf.getLong(MediaFormat.KEY_DURATION) else 0L
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, videoSrc)
                rotation = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (videoDurUs <= 0L) {
                    videoDurUs = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000L
                }
            } finally {
                r.release()
            }

            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            val vt = m.addTrack(vf)
            val at = m.addTrack(af)
            m.setOrientationHint(rotation)
            m.start()
            started = true

            vx.selectTrack(vi)
            ax.selectTrack(ai)

            var maxSize = 1 shl 20
            if (vf.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) maxSize = maxOf(maxSize, vf.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
            if (af.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) maxSize = maxOf(maxSize, af.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE))
            val buf = ByteBuffer.allocateDirect(maxSize + 1024)
            val info = MediaCodec.BufferInfo()
            var audioDone = false
            var written = 0

            while (true) {
                val vTime = vx.sampleTime
                val aTime = if (audioDone) -1L else ax.sampleTime
                if (vTime < 0L && aTime < 0L) break

                val useVideo = vTime >= 0L && (aTime < 0L || vTime <= aTime)
                if (useVideo) {
                    buf.clear()
                    val size = vx.readSampleData(buf, 0)
                    if (size < 0) {
                        if (!vx.advance()) break
                        continue
                    }
                    val flags = if ((vx.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    info.set(0, size, vTime, flags)
                    m.writeSampleData(vt, buf, info)
                    written++
                    vx.advance()
                } else {
                    if (videoDurUs > 0L && aTime > videoDurUs) {
                        audioDone = true
                        continue
                    }
                    buf.clear()
                    val size = ax.readSampleData(buf, 0)
                    if (size < 0) {
                        audioDone = true
                        continue
                    }
                    info.set(0, size, aTime, MediaCodec.BUFFER_FLAG_KEY_FRAME)
                    m.writeSampleData(at, buf, info)
                    written++
                    if (!ax.advance()) audioDone = true
                }
            }
            if (written == 0) throw IllegalStateException("Leeres Ergebnis.")
            try {
                m.stop()
            } finally {
                started = false
            }
        } finally {
            try {
                if (started) muxer?.stop()
            } catch (e: Exception) {
                // egal
            }
            try {
                muxer?.release()
            } catch (e: Exception) {
                // egal
            }
            vx.release()
            ax.release()
        }
    }
}
