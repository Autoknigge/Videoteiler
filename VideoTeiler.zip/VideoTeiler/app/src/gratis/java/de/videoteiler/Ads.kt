package de.videoteiler

import android.app.Activity
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Werbung (Gratis- und Start-Ausgabe): erst Einwilligung (EU), dann
 * Gratis: Banner am unteren Rand; Start: einmal eine App-Start-Anzeige (App Open).
 */
object Ads {
    const val enabled = true
    private val initialized = AtomicBoolean(false)

    /** Führt [block] aus, sobald Werbung angefordert werden darf (nach der Einwilligung). */
    private fun whenAllowed(activity: Activity, block: () -> Unit) {
        val ci = UserMessagingPlatform.getConsentInformation(activity)
        val done = AtomicBoolean(false)
        fun go() {
            if ((ci.canRequestAds() || testMode(activity)) && done.compareAndSet(false, true)) block()
        }
        fun check() {
            if (!ci.canRequestAds()) debug(activity, "Werbung: Einwilligung fehlt (Status ${ci.consentStatus})")
            go()
        }
        ci.requestConsentInfoUpdate(
            activity,
            ConsentRequestParameters.Builder().build(),
            { UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { err ->
                if (err != null) debug(activity, "Einwilligung: ${err.message}")
                check()
            } },
            { err -> debug(activity, "Einwilligung: ${err.message}"); check() }
        )
        // Einwilligung wurde bei einem früheren Start schon erteilt.
        go()
    }

    /** Meldet Werbefehler als kurze Einblendung, damit man sieht, warum keine Anzeige kommt. Später auf false setzen. */
    private const val DEBUG_ADS = true

    private fun debug(activity: Activity, msg: String) {
        if (DEBUG_ADS) activity.runOnUiThread { Toast.makeText(activity, msg, Toast.LENGTH_LONG).show() }
    }

    /** Im Testmodus Googles Test-Anzeigenblock, sonst der eigene. */
    private fun unitId(activity: Activity, testId: String, realRes: Int): String =
        if (activity.resources.getBoolean(R.bool.admob_test_mode)) testId else activity.getString(realRes)

    /** Im Testmodus (siehe ads.xml) werden Testanzeigen auch ohne Einwilligungsformular angefordert. */
    private fun testMode(activity: Activity): Boolean = activity.resources.getBoolean(R.bool.admob_test_mode)

    private fun init(activity: Activity) {
        if (initialized.compareAndSet(false, true)) MobileAds.initialize(activity) { }
    }

    /** Gratis-Ausgabe: Banner unten. */
    fun attach(activity: Activity, container: LinearLayout) {
        whenAllowed(activity) { showBanner(activity, container) }
    }

    private fun showBanner(activity: Activity, container: LinearLayout) {
        if (activity.isFinishing || activity.isDestroyed) return
        if (container.findViewWithTag<View>("ad") != null) return
        init(activity)
        val view = AdView(activity)
        view.tag = "ad"
        val dm = activity.resources.displayMetrics
        val widthDp = (dm.widthPixels / dm.density).toInt()
        view.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, widthDp))
        view.adUnitId = unitId(activity, "ca-app-pub-3940256099942544/9214589741", R.string.admob_banner_id)
        container.addView(
            view,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { gravity = Gravity.CENTER_HORIZONTAL }
        )
        view.adListener = object : AdListener() {
            override fun onAdFailedToLoad(error: LoadAdError) {
                debug(activity, "Banner: Fehler ${error.code} – ${error.message}")
            }
        }
        view.loadAd(AdRequest.Builder().build())
    }

    /**
     * Start-Ausgabe: lädt die App-Start-Anzeige und zeigt sie, sobald sie bereit ist ([canShow] muss dann noch stimmen).
     * [onClosed]: Anzeige wurde geschlossen. [onFailed]: keine Anzeige (Fehler oder zu spät).
     */
    fun showIntroAd(activity: Activity, canShow: () -> Boolean, onClosed: () -> Unit, onFailed: () -> Unit) {
        whenAllowed(activity) {
            init(activity)
            AppOpenAd.load(
                activity,
                unitId(activity, "ca-app-pub-3940256099942544/9257395921", R.string.admob_appopen_id),
                AdRequest.Builder().build(),
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        if (activity.isFinishing || activity.isDestroyed || !canShow()) {
                            onFailed()
                            return
                        }
                        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() = onClosed()
                            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) = onFailed()
                        }
                        ad.show(activity)
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        debug(activity, "Startanzeige: Fehler ${error.code} – ${error.message}")
                        onFailed()
                    }
                }
            )
        }
    }

    /** Öffnet die Werbe-Einstellungen: Einwilligungsformular, falls nötig, sonst eine Erklärung mit Link zu Google. */
    fun showPrivacyOptions(activity: Activity) {
        val ci = UserMessagingPlatform.getConsentInformation(activity)
        if (ci.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
            UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ -> }
            return
        }
        android.app.AlertDialog.Builder(activity)
            .setTitle("Werbe-Einstellungen")
            .setMessage(
                "Für dich ist hier keine Einwilligungsabfrage nötig, oder sie ist noch nicht eingerichtet. " +
                    "Wie Google Werbung für dich personalisiert, kannst du in den Anzeigen-Einstellungen von Google ändern."
            )
            .setPositiveButton("Google-Einstellungen") { _, _ ->
                try {
                    activity.startActivity(
                        android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://adssettings.google.com"))
                    )
                } catch (e: Exception) {
                    Toast.makeText(activity, "Kein Browser gefunden.", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Schließen", null)
            .show()
    }
}
