package de.videoteiler

import android.app.Activity
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Werbung (Gratis- und Start-Ausgabe): erst Einwilligung (EU), dann
 * Gratis: Banner am unteren Rand; Start: einmal eine App-Start-Anzeige (App Open).
 */
object Ads {
    const val enabled = true
    private val initialized = AtomicBoolean(false)

    /** Führt [block] aus, sobald Werbung angefordert werden darf (nach der Einwilligung). */
    private fun whenAllowed(activity: Activity, block: () -> Unit) {
        val ci = UserMessagingPlatform.getConsentInformation(activity)
        val done = AtomicBoolean(false)
        fun go() {
            if (ci.canRequestAds() && done.compareAndSet(false, true)) block()
        }
        ci.requestConsentInfoUpdate(
            activity,
            ConsentRequestParameters.Builder().build(),
            { UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ -> go() } },
            { _ -> go() }
        )
        // Einwilligung wurde bei einem früheren Start schon erteilt.
        go()
    }

    private fun init(activity: Activity) {
        if (initialized.compareAndSet(false, true)) MobileAds.initialize(activity) { }
    }

    /** Gratis-Ausgabe: Banner unten. */
    fun attach(activity: Activity, container: LinearLayout) {
        whenAllowed(activity) { showBanner(activity, container) }
    }

    private fun showBanner(activity: Activity, container: LinearLayout) {
        if (activity.isFinishing || activity.isDestroyed) return
        if (container.findViewWithTag<View>("ad") != null) return
        init(activity)
        val view = AdView(activity)
        view.tag = "ad"
        view.setAdSize(AdSize.BANNER)
        view.adUnitId = activity.getString(R.string.admob_banner_id)
        container.addView(
            view,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { gravity = Gravity.CENTER_HORIZONTAL }
        )
        view.loadAd(AdRequest.Builder().build())
    }

    /** Start-Ausgabe: lädt die App-Start-Anzeige und zeigt sie, sobald sie bereit ist. */
    fun showIntroAd(activity: Activity) {
        whenAllowed(activity) {
            init(activity)
            AppOpenAd.load(
                activity,
                activity.getString(R.string.admob_appopen_id),
                AdRequest.Builder().build(),
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        if (activity.isFinishing || activity.isDestroyed) return
                        ad.fullScreenContentCallback = object : FullScreenContentCallback() {}
                        ad.show(activity)
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        // Keine Anzeige: der Start läuft ganz normal weiter.
                    }
                }
            )
        }
    }

    /** Öffnet die Datenschutz-Einstellungen für Werbung, falls sie in diesem Land nötig sind. */
    fun showPrivacyOptions(activity: Activity) {
        val ci = UserMessagingPlatform.getConsentInformation(activity)
        if (ci.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
            UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ -> }
        } else {
            Toast.makeText(activity, "Hier sind keine Einstellungen nötig.", Toast.LENGTH_LONG).show()
        }
    }
}
