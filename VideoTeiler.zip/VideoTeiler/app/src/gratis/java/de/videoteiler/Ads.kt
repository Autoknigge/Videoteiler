package de.videoteiler

import android.app.Activity
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

/** Werbung der Gratis-Ausgabe: erst Einwilligung (EU), dann ein Banner am unteren Rand. */
object Ads {
    const val enabled = true
    private val initialized = AtomicBoolean(false)

    fun attach(activity: Activity, container: LinearLayout) = request(activity, container, AdSize.BANNER)

    /** Große Anzeige (300x250) für den Startbildschirm der Start-Ausgabe. */
    fun attachIntro(activity: Activity, container: LinearLayout) = request(activity, container, AdSize.MEDIUM_RECTANGLE)

    private fun request(activity: Activity, container: LinearLayout, size: AdSize) {
        val ci = UserMessagingPlatform.getConsentInformation(activity)
        val params = ConsentRequestParameters.Builder().build()
        ci.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { _ ->
                    if (ci.canRequestAds()) show(activity, container, size)
                }
            },
            { _ -> if (ci.canRequestAds()) show(activity, container, size) }
        )
        // Einwilligung wurde bei einem früheren Start schon erteilt.
        if (ci.canRequestAds()) show(activity, container, size)
    }

    private fun show(activity: Activity, container: LinearLayout, size: AdSize) {
        if (activity.isFinishing || activity.isDestroyed) return
        if (container.findViewWithTag<View>("ad") != null) return
        if (initialized.compareAndSet(false, true)) MobileAds.initialize(activity) { }
        val view = AdView(activity)
        view.tag = "ad"
        view.setAdSize(size)
        view.adUnitId = activity.getString(R.string.admob_banner_id)
        container.addView(
            view,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { gravity = Gravity.CENTER_HORIZONTAL }
        )
        view.loadAd(AdRequest.Builder().build())
    }

    /** Öffnet die Datenschutz-Einstellungen für Werbung, falls sie in diesem Land nötig sind. */
    fun showPrivacyOptions(activity: Activity) {
        val ci = UserMessagingPlatform.getConsentInformation(activity)
        if (ci.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
            UserMessagingPlatform.showPrivacyOptionsForm(activity) { _ -> }
        } else {
            Toast.makeText(activity, "Hier sind keine Einstellungen nötig.", Toast.LENGTH_LONG).show()
        }
    }
}
