plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.videoteiler"
    compileSdk = 36

    defaultConfig {
        minSdk = 30
        targetSdk = 36
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0) + 100
        // Wird vom Bau-Ablauf (GitHub) bei jeder Veröffentlichung hochgezählt: 1.0, 1.1, 1.2 ...
        versionName = System.getenv("VERSION_NAME") ?: "1.0"
        resValue("bool", "intro_ad", "false")
    }

    // Zwei Ausgaben: "gratis" (mit Werbung) und "pro" (ohne Werbung, ohne Internet).
    flavorDimensions += "edition"
    productFlavors {
        create("gratis") {
            dimension = "edition"
            applicationId = "de.videoteiler"
            resValue("string", "app_name", "Video-Teiler")
        }
        // Wie "gratis", aber statt des Banners kommt einmal beim Start eine kurze Anzeige mit Wartezeit.
        create("start") {
            dimension = "edition"
            applicationId = "de.videoteiler.start"
            resValue("string", "app_name", "Video-Teiler Start")
            resValue("bool", "intro_ad", "true")
        }
        create("pro") {
            dimension = "edition"
            applicationId = "de.videoteiler.pro"
            resValue("string", "app_name", "Video-Teiler Pro")
        }
    }

    // Die Start-Ausgabe nutzt denselben Werbe-Code wie die Gratis-Ausgabe.
    sourceSets.getByName("start") {
        java.srcDir("src/gratis/java")
        res.srcDir("src/gratis/res")
        manifest.srcFile("src/gratis/AndroidManifest.xml")
    }

    val keystoreFile = System.getenv("KEYSTORE_FILE")?.let { file(it) }
    val hasKey = keystoreFile != null && keystoreFile.exists()

    signingConfigs {
        if (hasKey) {
            create("fest") {
                storeFile = keystoreFile
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = "statussicherer"
                keyPassword = System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Mit festem Schlüssel signieren, damit Updates über die alte App installierbar sind.
            signingConfig = if (hasKey) signingConfigs.getByName("fest") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Zum Umwandeln von Videos, die sich nicht verlustfrei umpacken lassen (zum Beispiel VP9).
    implementation("androidx.media3:media3-transformer:1.5.1")
    implementation("androidx.media3:media3-common:1.5.1")

    // Werbung und Einwilligungsabfrage nur in der Gratis-Ausgabe.
    "gratisImplementation"("com.google.android.gms:play-services-ads:23.6.0")
    "startImplementation"("com.google.android.gms:play-services-ads:23.6.0")
    "startImplementation"("com.google.android.ump:user-messaging-platform:3.1.0")
    "gratisImplementation"("com.google.android.ump:user-messaging-platform:3.1.0")
}
