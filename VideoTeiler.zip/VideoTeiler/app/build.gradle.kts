plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.videoteiler"
    compileSdk = 36

    defaultConfig {
        minSdk = 30
        targetSdk = 36
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0) + 100
        versionName = "1.1"
    }

    // Zwei Ausgaben: "gratis" (mit Werbung) und "pro" (ohne Werbung, ohne Internet).
    flavorDimensions += "edition"
    productFlavors {
        create("gratis") {
            dimension = "edition"
            applicationId = "de.videoteiler"
            resValue("string", "app_name", "Video-Teiler")
        }
        create("pro") {
            dimension = "edition"
            applicationId = "de.videoteiler.pro"
            resValue("string", "app_name", "Video-Teiler Pro")
        }
    }

    val keystoreFile = System.getenv("KEYSTORE_FILE")?.let { file(it) }
    val hasKey = keystoreFile != null && keystoreFile.exists()

    signingConfigs {
        if (hasKey) {
            create("fest") {
                storeFile = keystoreFile
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = "statussicherer"
                keyPassword = System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Mit festem Schlüssel signieren, damit Updates über die alte App installierbar sind.
            signingConfig = if (hasKey) signingConfigs.getByName("fest") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Zum Umwandeln von Videos, die sich nicht verlustfrei umpacken lassen (zum Beispiel VP9).
    implementation("androidx.media3:media3-transformer:1.5.1")
    implementation("androidx.media3:media3-common:1.5.1")

    // Werbung und Einwilligungsabfrage nur in der Gratis-Ausgabe.
    "gratisImplementation"("com.google.android.gms:play-services-ads:23.6.0")
    "gratisImplementation"("com.google.android.ump:user-messaging-platform:3.1.0")
}
