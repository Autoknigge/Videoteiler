plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.videoteiler"
    compileSdk = 36

    defaultConfig {
        applicationId = "de.videoteiler"
        minSdk = 30
        targetSdk = 36
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0) + 100
        versionName = "1.1"
    }

    val keystoreFile = System.getenv("KEYSTORE_FILE")?.let { file(it) }
    val hasKey = keystoreFile != null && keystoreFile.exists()

    signingConfigs {
        if (hasKey) {
            create("fest") {
                storeFile = keystoreFile
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = "statussicherer"
                keyPassword = System.getenv("KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Mit festem Schlüssel signieren, damit Updates über die alte App installierbar sind.
            signingConfig = if (hasKey) signingConfigs.getByName("fest") else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
