# Video-Teiler

Android-App, die ein langes Video in Teile von 30, 60 oder 90 Sekunden schneidet, damit sie als WhatsApp-Status passen. Die Teile werden in der Galerie unter „Filme/Video-Teiler“ gespeichert und lassen sich mit einem Tipp an WhatsApp oder WhatsApp Business schicken.

- Das Video wird nicht neu berechnet, nur umgepackt. Das geht schnell und die Qualität bleibt unverändert.
- Geschnitten wird an Schlüsselbildern. Die Teile sind deshalb meist ein paar Sekunden kürzer als gewählt, aber nie länger.
- Die App braucht keine Berechtigungen und hat keinen Internetzugriff.
- Videos im H.264-/H.265-Format werden verlustfrei umgepackt (schnell). Andere Formate, zum Beispiel VP9 aus Instagram-Downloads, wandelt die App automatisch nach H.264 um. Das dauert länger und ist die einzige Variante mit minimalem Qualitätsverlust.
- Voraussetzung: Android 11 oder neuer.

## Benutzen

1. „Video auswählen“ antippen (oder in der Galerie ein Video teilen und „Video-Teiler“ wählen).
2. Länge pro Teil wählen, „In Teile schneiden“ antippen.
3. „An WhatsApp“ oder „An WhatsApp Business“ antippen und dort oben „Mein Status“ wählen. Mit „Teilen“ bei einem einzelnen Teil lässt sich auch nur dieser Teil schicken.

WhatsApp bietet keine Möglichkeit, Status automatisch zu posten. Das letzte Antippen von „Mein Status“ bleibt deshalb bei dir.

## Neue Version bauen

1. Neue `VideoTeiler.zip` im Hauptordner des Repositorys hochladen (nicht entpacken).
2. Unter „Actions“ prüfen, dass der Lauf grün ist.
3. Die APK liegt unter „Releases“ im Eintrag „aktuell“:
   `https://github.com/Autoknigge/Videoteiler/releases/download/aktuell/Video-Teiler.apk`

Für Updates über die installierte App: Geheimnisse `KEYSTORE_BASE64` und `KEYSTORE_PASSWORD` unter „Einstellungen“ → „Geheimnisse und Variablen“ → „Actions“ eintragen (dieselben Werte wie bei Status-Sicherer sind möglich).
