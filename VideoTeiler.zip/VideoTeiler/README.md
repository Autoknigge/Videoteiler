# Video-Teiler

Android-App mit vier kleinen Werkzeugen für Videos und den WhatsApp-Status.

1. **Video teilen:** Schneidet ein langes Video in Teile à 30, 60 oder 90 Sekunden und schickt sie an WhatsApp oder WhatsApp Business („Mein Status“ wählen).
2. **Status sichern:** Findet die angesehenen Status von WhatsApp und WhatsApp Business selbst und speichert Bilder und Videos in der Galerie.
3. **Ton aus Video holen:** Speichert die Tonspur eines Videos als m4a-Datei unter Musik/Video-Teiler.
4. **Ton und Video zusammenführen:** Ein Video bekommt den Ton einer Audiodatei (der Originalton wird ersetzt). Das Ergebnis ist so lang wie das Video.

Hinweise
- Videos im H.264-/H.265-Format werden beim Teilen verlustfrei umgepackt (schnell). Andere Formate, zum Beispiel VP9 aus Instagram-Downloads, wandelt die App automatisch nach H.264 um. Das dauert länger.
- Für „Status sichern“ braucht die App den „Zugriff auf alle Dateien“ (oder die Freigabe des WhatsApp-Ordners). Die anderen Werkzeuge brauchen keine Berechtigung.
- Die App hat keinen Internetzugriff und lädt nichts hoch.
- WhatsApp bietet keine Möglichkeit, Status automatisch zu posten. Das letzte Antippen von „Mein Status“ bleibt bei dir.
- Speichere und teile fremde Inhalte nur mit Erlaubnis.
- Voraussetzung: Android 11 oder neuer.

## Neue Version bauen

1. Neue `VideoTeiler.zip` im Hauptordner des Repositorys hochladen (nicht entpacken).
2. Unter „Actions“ prüfen, dass der Lauf grün ist.
3. Die APK liegt unter „Releases“ im Eintrag „aktuell“:
   `https://github.com/Autoknigge/Videoteiler/releases/download/aktuell/Video-Teiler.apk`

Für Updates über die installierte App: Geheimnisse `KEYSTORE_BASE64` und `KEYSTORE_PASSWORD` unter „Einstellungen“ → „Geheimnisse und Variablen“ → „Actions“ eintragen.
